@echo off
cd /d "%~dp0"
set BARYOKONEK_DB_URL=jdbc:postgresql://localhost:5432/baryokonek
set BARYOKONEK_DB_USER=baryokonek_app
set BARYOKONEK_DB_PASSWORD=ChangeThisPassword123!

java -version
if errorlevel 1 (
  echo Java 25 is not installed or JAVA_HOME/PATH is not configured.
  pause
  exit /b 1
)

if not exist "target\BaryoKonek.jar" (
  echo Application JAR not found. Build first using: mvn clean package
  pause
  exit /b 1
)
java -jar target\BaryoKonek.jar
pause
