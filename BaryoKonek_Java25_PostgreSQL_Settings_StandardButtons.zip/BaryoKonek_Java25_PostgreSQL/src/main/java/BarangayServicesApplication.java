import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.sql.*;
 
public class BarangayServicesApplication extends JFrame {
 
    // ---------- Palette ----------
    private static final Color NAVY = new Color(8, 57, 112);
    private static final Color BLUE = new Color(0, 111, 210);
    private static final Color INK = new Color(30, 41, 59);
 
    // Theme colors (dark by default; can be switched to light)
    private static boolean darkMode = true;
    private static Color G_TOP, G_BOTTOM, TXT, TXT_SOFT, LINK, CARD, CARD_BORDER,
            ROW_A, ROW_B, SELECT, TH_BG, GRID;
    private static String HEX_TXT, HEX_SOFT;
    private static final File THEME_FILE = new File("barangay_theme.txt");
    // Notification read-state is kept separately for each account. Admin and resident
    // accounts therefore do not accidentally clear each other's notification badges.
    private static Set<String> loadViewedNotificationKeys(File file) {
        Set<String> keys = new HashSet<>();
        if (!file.exists()) return keys;
        try {
            for (String line : Files.readAllLines(file.toPath(), StandardCharsets.UTF_8)) {
                String value = line.trim();
                if (!value.isEmpty()) keys.add(value);
            }
        } catch (Exception ignored) { }
        return keys;
    }

    // Notification alert preference is persisted separately for every account.
    // Alerts are enabled by default so existing users keep receiving notifications.
    private static boolean loadNotificationPreference(File file) {
        if (!file.exists()) return true;
        try {
            return !"off".equalsIgnoreCase(new String(
                    Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8).trim());
        } catch (Exception ignored) { return true; }
    }

    private static void applyTheme(boolean dark) {
        darkMode = dark;
        if (dark) {
            G_TOP = new Color(0, 111, 210);      G_BOTTOM = new Color(3, 8, 18);
            TXT = Color.WHITE;                   TXT_SOFT = new Color(190, 214, 240);
            LINK = new Color(120, 195, 255);
            CARD = new Color(6, 14, 30, 225);    CARD_BORDER = new Color(70, 140, 220, 160);
            ROW_A = new Color(10, 22, 44);       ROW_B = new Color(16, 34, 64);
            SELECT = new Color(24, 72, 130);
            TH_BG = new Color(12, 44, 88);       GRID = new Color(30, 55, 90);
            HEX_TXT = "#FFFFFF";                 HEX_SOFT = "#BED6F0";
        } else {
            G_TOP = new Color(196, 222, 250);    G_BOTTOM = new Color(242, 247, 253);
            TXT = new Color(20, 33, 56);         TXT_SOFT = new Color(71, 92, 122);
            LINK = new Color(0, 98, 190);
            CARD = new Color(255, 255, 255, 245); CARD_BORDER = new Color(150, 185, 225);
            ROW_A = Color.WHITE;                 ROW_B = new Color(240, 246, 254);
            SELECT = new Color(197, 220, 249);
            TH_BG = new Color(212, 229, 248);    GRID = new Color(214, 226, 242);
            HEX_TXT = "#14213A";                 HEX_SOFT = "#475C7A";
        }
        try {
            Files.write(THEME_FILE.toPath(), (dark ? "dark" : "light").getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) { }
    }

    static {
        boolean dark = true;
        try {
            if (THEME_FILE.exists())
                dark = !"light".equals(new String(Files.readAllBytes(THEME_FILE.toPath()), StandardCharsets.UTF_8).trim());
        } catch (Exception ignored) { }
        applyTheme(dark);
    }
 
    private static final String[] ADMIN_PAGES = {"Home", "Residents", "Barangay Documents", "Document Requests", "History",
            "Announcements", "Notifications", "Settings"};
    private static final String[] RESIDENT_PAGES = {"Home", "Barangay Documents", "Document Requests", "History",
            "Announcements", "Notifications", "Settings"};
 
    private final User currentUser;
    private final File notificationReadFile;
    private final File notificationSettingsFile;
    private final Set<String> viewedNotificationKeys;
    private boolean notificationsEnabled = true;
    private final String[] pages;
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel pageCards = new JPanel(cardLayout);
    private final List<NavButton> navButtons = new ArrayList<>();
    private final JPanel dashboardWrap = new JPanel(new BorderLayout());
    private final JPanel announcementsWrap = new JPanel(new BorderLayout());
    private final JPanel notificationsWrap = new JPanel(new BorderLayout());
    private final JPanel requestsWrap = new JPanel(new BorderLayout());
    private final JPanel historyWrap = new JPanel(new BorderLayout());
    private final List<String[]> annSources = new ArrayList<>();   // {storeKey, index} for each row of the admin "All Announcements" table
    private String currentPage = "Home";
    private javax.swing.Timer notificationRefreshTimer;
    private JDialog notificationPopup;
    private final Set<String> knownNotificationKeys = new HashSet<>();

    // Main application shell components. The upper banner/header is intentionally
    // omitted; the sidebar and page content now start at the top edge of the frame.
    private GradientPanel sidebarPanel;
    private JPanel sidebarBrandPanel;
    private JPanel sidebarBrandText;
    private BarangayPhoto sidebarLogo;
    private JPanel sidebarNavList;
    private RoundPanel sidebarUserCard;
    private JLabel sidebarUserLabel;
    private LinkButton sidebarLogoutButton;
    private JPanel contentPanel;
    private int responsiveMode = -1;
 
    private static Font font(int style, int size) {
        return new Font("Segoe UI", style, size);
    }
 
    private static void aa(Graphics2D g2) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    }
 
    private static String esc(String s) {
        return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
 
    private static String enc(String s) {
        return Base64.getEncoder().encodeToString((s == null ? "" : s).getBytes(StandardCharsets.UTF_8));
    }
 
    private static String dec(String s) {
        return new String(Base64.getDecoder().decode(s), StandardCharsets.UTF_8);
    }
 
    private boolean isAdmin() {
        return currentUser.isAdmin();
    }
 
    // =====================================================================
    //  Accounts & storage
    // =====================================================================
 
    /** A user account. role is "ADMIN" (barangay admin) or "RESIDENT". */
    static class User {
        final String role, username;
        String salt, hash;
        String fullName, purok, contact, address;
 
        User(String role, String username, String salt, String hash,
             String fullName, String purok, String contact, String address) {
            this.role = role; this.username = username; this.salt = salt; this.hash = hash;
            this.fullName = fullName; this.purok = purok; this.contact = contact; this.address = address;
        }
 
        boolean isAdmin() { return "ADMIN".equals(role); }
 
        String firstName() {
            String n = fullName == null ? "" : fullName.trim();
            int sp = n.indexOf(' ');
            return sp > 0 ? n.substring(0, sp) : n;
        }
    }
 
    /**
     * Stores accounts in barangay_users.txt (next to the program). Passwords are never saved in plain
     * text: each one is salted and hashed (SHA-256, repeated 20000 times).
     *
     * Two portals:
     *   - Resident : self sign-up + sign-in (role RESIDENT)
     *   - Staff    : log-in only (role ADMIN). Default staff account is created the first time:
     *                username "admin", password "admin123".
     *
     * Staff can also create resident accounts from the Residents page (temporary password is shown once).
     */
    static class Database {
        private static final String URL = System.getenv().getOrDefault("BARYOKONEK_DB_URL", "jdbc:postgresql://localhost:5432/baryokonek");
        private static final String USER = System.getenv().getOrDefault("BARYOKONEK_DB_USER", "postgres");
        private static final String PASSWORD = System.getenv().getOrDefault("BARYOKONEK_DB_PASSWORD", "postgres");

        static java.sql.Connection connect() throws java.sql.SQLException {
            return java.sql.DriverManager.getConnection(URL, USER, PASSWORD);
        }

        static void initialize() throws java.sql.SQLException {
            try (java.sql.Connection c = connect(); java.sql.Statement s = c.createStatement()) {
                s.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS app_users (
                      username VARCHAR(20) PRIMARY KEY,
                      role VARCHAR(10) NOT NULL CHECK (role IN ('ADMIN','RESIDENT')),
                      password_salt TEXT NOT NULL,
                      password_hash TEXT NOT NULL,
                      full_name TEXT NOT NULL,
                      purok TEXT,
                      contact VARCHAR(20),
                      address TEXT
                    )
                    """);
                s.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS list_items (
                      id BIGSERIAL PRIMARY KEY,
                      category VARCHAR(40) NOT NULL,
                      row_data TEXT[] NOT NULL
                    )
                    """);
                s.executeUpdate("CREATE INDEX IF NOT EXISTS idx_list_items_category ON list_items(category, id)");
                s.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS document_requests (
                      request_id VARCHAR(30) PRIMARY KEY,
                      document_type TEXT NOT NULL,
                      resident_name TEXT NOT NULL,
                      purpose TEXT,
                      request_date TEXT,
                      status TEXT NOT NULL,
                      completed_at TIMESTAMP,
                      quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity >= 1)
                    )
                    """);
                migrateLegacyFiles(c);
                // Persist the exact time a request enters Completed so a later completion
                // can trigger a fresh notification even if the same request was completed before.
                s.executeUpdate("ALTER TABLE document_requests ADD COLUMN IF NOT EXISTS completed_at TIMESTAMP");
                s.executeUpdate("ALTER TABLE document_requests ADD COLUMN IF NOT EXISTS quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity >= 1)");
                s.executeUpdate("UPDATE document_requests SET completed_at = CURRENT_TIMESTAMP "
                        + "WHERE LOWER(status) = 'completed' AND completed_at IS NULL");

                // One-time migration from the previous request workflow:
                // old Pending requests were awaiting staff action; old Processing
                // requests had already been accepted and are now represented as Pending.
                s.executeUpdate("CREATE TABLE IF NOT EXISTS app_migrations (migration_key VARCHAR(120) PRIMARY KEY, applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)");
                try (java.sql.PreparedStatement checkMigration =
                             c.prepareStatement("SELECT 1 FROM app_migrations WHERE migration_key = ?")) {
                    checkMigration.setString(1, "document_request_accept_complete_v1");
                    try (java.sql.ResultSet migrated = checkMigration.executeQuery()) {
                        if (!migrated.next()) {
                            s.executeUpdate("UPDATE document_requests SET status = 'For Acceptance' WHERE LOWER(status) IN ('pending', 'requested')");
                            s.executeUpdate("UPDATE document_requests SET status = 'Pending' WHERE LOWER(status) IN ('processing', 'ongoing')");
                            try (java.sql.PreparedStatement markMigration = c.prepareStatement(
                                    "INSERT INTO app_migrations(migration_key) VALUES (?) ON CONFLICT DO NOTHING")) {
                                markMigration.setString(1, "document_request_accept_complete_v1");
                                markMigration.executeUpdate();
                            }
                        }
                    }
                }
            }
        }

        // One-time import of the old TXT storage when the corresponding PostgreSQL table is empty.
        private static void migrateLegacyFiles(java.sql.Connection c) throws java.sql.SQLException {
            try (java.sql.Statement check = c.createStatement();
                 java.sql.ResultSet r = check.executeQuery("SELECT COUNT(*) FROM app_users")) {
                if (r.next() && r.getInt(1) == 0) {
                    java.io.File oldUsers = new java.io.File("barangay_users.txt");
                    if (oldUsers.exists()) {
                        try (java.sql.PreparedStatement p = c.prepareStatement(
                            "INSERT INTO app_users(role,username,password_salt,password_hash,full_name,purok,contact,address) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT DO NOTHING")) {
                            for (String line : java.nio.file.Files.readAllLines(oldUsers.toPath(), StandardCharsets.UTF_8)) {
                                String[] v=line.split(",",-1); if(v.length!=8) continue;
                                for(int i=0;i<8;i++) p.setString(i+1,dec(v[i]));
                                p.addBatch();
                            }
                            p.executeBatch();
                        } catch(Exception ex) { System.err.println("Legacy users import skipped: "+ex.getMessage()); }
                    }
                }
            }
            try (java.sql.Statement check = c.createStatement();
                 java.sql.ResultSet r = check.executeQuery("SELECT COUNT(*) FROM document_requests")) {
                if (r.next() && r.getInt(1) == 0) {
                    java.io.File oldRequests = new java.io.File("barangay_requests.txt");
                    if (oldRequests.exists()) {
                        try (java.sql.PreparedStatement p = c.prepareStatement(
                            "INSERT INTO document_requests(request_id,document_type,resident_name,purpose,request_date,status) VALUES(?,?,?,?,?,?) ON CONFLICT DO NOTHING")) {
                            for(String line:java.nio.file.Files.readAllLines(oldRequests.toPath(),StandardCharsets.UTF_8)) {
                                String[] v=line.split(",",-1); if(v.length!=6) continue;
                                for(int i=0;i<6;i++) p.setString(i+1,dec(v[i]));
                                p.addBatch();
                            }
                            p.executeBatch();
                        } catch(Exception ex) { System.err.println("Legacy requests import skipped: "+ex.getMessage()); }
                    }
                }
            }
            boolean listTableEmpty = false;
            try (java.sql.Statement check=c.createStatement();
                 java.sql.ResultSet r=check.executeQuery("SELECT COUNT(*) FROM list_items")) {
                listTableEmpty = r.next() && r.getLong(1)==0;
            }
            if (listTableEmpty) try (java.util.stream.Stream<java.nio.file.Path> paths=java.nio.file.Files.list(java.nio.file.Path.of("."))) {
                paths.filter(path -> {
                    String n=path.getFileName().toString();
                    return n.startsWith("barangay_") && n.endsWith(".txt")
                        && !n.equals("barangay_users.txt") && !n.equals("barangay_requests.txt")
                        && !n.equals("barangay_theme.txt");
                }).forEach(path -> {
                    String n=path.getFileName().toString();
                    String category=n.substring("barangay_".length(),n.length()-".txt".length());
                    try (java.sql.PreparedStatement p=c.prepareStatement("INSERT INTO list_items(category,row_data) VALUES(?,?)")) {
                        for(String line:java.nio.file.Files.readAllLines(path,StandardCharsets.UTF_8)) {
                            if(line.isBlank()) continue;
                            String[] v=line.split(",",-1);
                            String[] values=new String[v.length];
                            for(int i=0;i<v.length;i++) values[i]=dec(v[i]);
                            p.setString(1,category); p.setArray(2,c.createArrayOf("text",values)); p.addBatch();
                        }
                        p.executeBatch();
                    } catch(Exception ex) { System.err.println("Legacy "+category+" import skipped: "+ex.getMessage()); }
                });
            } catch(Exception ex) { System.err.println("Legacy list import skipped: "+ex.getMessage()); }
        }
    }

    static class AuthManager {
        private static final List<User> USERS = new ArrayList<>();
        static {
            load();
            if (find("admin") == null) {
                USERS.add(create("ADMIN", "admin", "admin123", "Barangay Administrator", "", "", ""));
                save();
            }
        }

        private static String hash(String salt, String password) {
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                byte[] d = (salt + password).getBytes(StandardCharsets.UTF_8);
                for (int i = 0; i < 20000; i++) d = md.digest(d);
                return Base64.getEncoder().encodeToString(d);
            } catch (Exception e) { throw new RuntimeException(e); }
        }

        private static User create(String role, String username, String password,
                                   String fullName, String purok, String contact, String address) {
            byte[] s = new byte[16];
            new SecureRandom().nextBytes(s);
            String salt = Base64.getEncoder().encodeToString(s);
            return new User(role, username, salt, hash(salt, password), fullName, purok, contact, address);
        }

        private static synchronized void load() {
            USERS.clear();
            try (java.sql.Connection c = Database.connect();
                 java.sql.PreparedStatement p = c.prepareStatement(
                     "SELECT role, username, password_salt, password_hash, full_name, purok, contact, address FROM app_users ORDER BY username");
                 java.sql.ResultSet r = p.executeQuery()) {
                while (r.next()) USERS.add(new User(r.getString(1), r.getString(2), r.getString(3),
                    r.getString(4), r.getString(5), r.getString(6), r.getString(7), r.getString(8)));
            } catch (java.sql.SQLException e) { throw new RuntimeException("Cannot load users from PostgreSQL.", e); }
        }

        private static synchronized void save() {
            try (java.sql.Connection c = Database.connect();
                 java.sql.PreparedStatement p = c.prepareStatement("""
                    INSERT INTO app_users(role,username,password_salt,password_hash,full_name,purok,contact,address)
                    VALUES (?,?,?,?,?,?,?,?)
                    ON CONFLICT(username) DO UPDATE SET role=EXCLUDED.role,
                    password_salt=EXCLUDED.password_salt,password_hash=EXCLUDED.password_hash,
                    full_name=EXCLUDED.full_name,purok=EXCLUDED.purok,contact=EXCLUDED.contact,address=EXCLUDED.address
                    """)) {
                for (User u : USERS) {
                    p.setString(1,u.role); p.setString(2,u.username); p.setString(3,u.salt); p.setString(4,u.hash);
                    p.setString(5,u.fullName); p.setString(6,u.purok); p.setString(7,u.contact); p.setString(8,u.address);
                    p.addBatch();
                }
                p.executeBatch();
            } catch (java.sql.SQLException e) { throw new RuntimeException("Cannot save users to PostgreSQL.", e); }
        }

        static synchronized User find(String username) {
            for (User u : USERS) if (u.username.equalsIgnoreCase(username)) return u;
            return null;
        }

        static synchronized User authenticate(boolean admin, String username, String password) {
            User u = find(username);
            if (u == null || u.isAdmin() != admin) return null;
            boolean ok = MessageDigest.isEqual(hash(u.salt, password).getBytes(StandardCharsets.UTF_8),
                    u.hash.getBytes(StandardCharsets.UTF_8));
            return ok ? u : null;
        }

        static synchronized String registerResident(String fullName, String purok, String contact, String address,
                                                    String username, String password, String confirm) {
            if (fullName.trim().length() < 3) return "Please enter your full name.";
            if (!contact.matches("^(09\\d{9}|\\+639\\d{9})$")) return "Enter a valid mobile number (e.g. 09171234567).";
            if (address.trim().isEmpty()) return "Please enter your address.";
            if (!username.matches("^[A-Za-z0-9_.]{4,20}$")) return "Username must be 4-20 characters (letters, numbers, _ or .).";
            if (find(username) != null) return "That username is already taken.";
            if (password.length() < 6) return "Password must be at least 6 characters.";
            if (!password.equals(confirm)) return "Passwords do not match.";
            USERS.add(create("RESIDENT", username, password, fullName.trim(), purok, contact, address.trim()));
            save(); return null;
        }

        static synchronized String createResidentByAdmin(String fullName, String purok, String contact, String address, String username) {
            if (fullName.trim().length() < 3) return "ERROR: Please enter the resident's full name.";
            if (!contact.matches("^(09\\d{9}|\\+639\\d{9})$")) return "ERROR: Enter a valid mobile number (e.g. 09171234567).";
            if (address.trim().isEmpty()) return "ERROR: Please enter the address.";
            if (!username.matches("^[A-Za-z0-9_.]{4,20}$")) return "ERROR: Username must be 4-20 characters (letters, numbers, _ or .).";
            if (find(username) != null) return "ERROR: That username is already taken.";
            String tempPw = "res" + username.substring(0, 4) + "123";
            USERS.add(create("RESIDENT", username, tempPw, fullName.trim(), purok, contact, address.trim()));
            save(); return tempPw;
        }

        static synchronized String changePassword(User u, String oldPw, String newPw, String confirm) {
            if (!MessageDigest.isEqual(hash(u.salt, oldPw).getBytes(StandardCharsets.UTF_8), u.hash.getBytes(StandardCharsets.UTF_8)))
                return "Current password is incorrect.";
            if (newPw.length() < 6) return "New password must be at least 6 characters.";
            if (!newPw.equals(confirm)) return "New passwords do not match.";
            byte[] s = new byte[16]; new SecureRandom().nextBytes(s);
            u.salt = Base64.getEncoder().encodeToString(s); u.hash = hash(u.salt, newPw); save(); return null;
        }

        static synchronized String updateProfile(User u, String fullName, String purok, String contact, String address) {
            if (fullName == null || fullName.trim().length() < 3)
                return "Please enter your full name (at least 3 characters).";
            if (contact == null || !contact.trim().matches("^(09\\d{9}|\\+639\\d{9})$"))
                return "Enter a valid mobile number (e.g. 09171234567).";
            if (address == null || address.trim().isEmpty())
                return "Please enter your address.";
            u.fullName = fullName.trim();
            u.purok = purok == null ? "" : purok.trim();
            u.contact = contact.trim();
            u.address = address.trim();
            save();
            return null;
        }

        static synchronized List<User> residents() {
            List<User> list = new ArrayList<>();
            for (User u : USERS) if (!u.isAdmin()) list.add(u);
            return list;
        }
        static synchronized boolean usernameTaken(String username) { return find(username) != null; }
        static synchronized boolean deleteResident(String username) {
            User u = find(username);
            if (u == null || u.isAdmin()) return false;
            USERS.remove(u);
            try (java.sql.Connection c = Database.connect();
                 java.sql.PreparedStatement p = c.prepareStatement("DELETE FROM app_users WHERE username=? AND role='RESIDENT'")) {
                p.setString(1, username); p.executeUpdate(); return true;
            } catch (java.sql.SQLException e) { throw new RuntimeException("Cannot delete resident.", e); }
        }
    }

    static class ListStore {
        private static final java.util.Map<String, List<Object[]>> DATA = new java.util.HashMap<>();

        static synchronized List<Object[]> get(String key) {
            List<Object[]> list = DATA.get(key);
            if (list == null) {
                list = new ArrayList<>();
                try (java.sql.Connection c = Database.connect();
                     java.sql.PreparedStatement p = c.prepareStatement("SELECT row_data FROM list_items WHERE category=? ORDER BY id")) {
                    p.setString(1,key);
                    try (java.sql.ResultSet r = p.executeQuery()) {
                        while (r.next()) {
                            java.sql.Array a = r.getArray(1);
                            Object[] values = (Object[]) a.getArray();
                            list.add(values);
                            a.free();
                        }
                    }
                } catch (java.sql.SQLException e) { throw new RuntimeException("Cannot load " + key + " from PostgreSQL.", e); }
                // Earlier project versions stored health/education rows as
                // {title, category, date, status, actions}. Add a Location field
                // without losing the existing entries or their status.
                boolean migratedServiceRows = false;
                if ("health".equals(key) || "education".equals(key)) {
                    for (int i = 0; i < list.size(); i++) {
                        Object[] row = list.get(i);
                        if (row.length == 5 && "Edit / Delete".equals(String.valueOf(row[4]))) {
                            list.set(i, new Object[]{row[0], row[1], row[2], "", row[3], row[4]});
                            migratedServiceRows = true;
                        }
                    }
                }
                DATA.put(key,list);
                if (migratedServiceRows) write(key);
            }
            return list;
        }
        static synchronized Object[][] rows(String key) { return get(key).toArray(new Object[0][]); }

        /** Reload one category from PostgreSQL so availability checks see changes made by another session. */
        static synchronized List<Object[]> refresh(String key) {
            DATA.remove(key);
            return get(key);
        }

        private static void write(String key) {
            try (java.sql.Connection c = Database.connect()) {
                c.setAutoCommit(false);
                try (java.sql.PreparedStatement d = c.prepareStatement("DELETE FROM list_items WHERE category=?")) {
                    d.setString(1,key); d.executeUpdate();
                }
                try (java.sql.PreparedStatement p = c.prepareStatement("INSERT INTO list_items(category,row_data) VALUES (?,?)")) {
                    for (Object[] row : get(key)) {
                        String[] values = new String[row.length];
                        for (int i=0;i<row.length;i++) values[i] = String.valueOf(row[i]);
                        p.setString(1,key); p.setArray(2,c.createArrayOf("text",values)); p.addBatch();
                    }
                    p.executeBatch();
                }
                c.commit();
            } catch (java.sql.SQLException e) { throw new RuntimeException("Cannot save " + key + " to PostgreSQL.", e); }
        }
        static synchronized void add(String key, Object[] row) { get(key).add(row.clone()); write(key); }
        static synchronized void set(String key, int index, Object[] row) {
            List<Object[]> list=get(key); if(index<0 || index>=list.size()) return;
            list.set(index,row.clone()); write(key);
        }
        static synchronized void remove(String key, int index) {
            List<Object[]> list=get(key); if(index<0 || index>=list.size()) return;
            list.remove(index); write(key);
        }
        static synchronized int count(String key, int col, String value) {
            int n=0; for(Object[] r:get(key)) if(r.length>col && value.equals(String.valueOf(r[col]))) n++; return n;
        }
    }

    static class RequestStore {
        private static final List<Object[]> ROWS = new ArrayList<>();
        private static final Map<String, String> COMPLETED_AT = new HashMap<>();

        static {
            try (java.sql.Connection c=Database.connect();
                 java.sql.PreparedStatement p=c.prepareStatement("SELECT request_id,document_type,resident_name,purpose,request_date,status,quantity,completed_at FROM document_requests ORDER BY request_id");
                 java.sql.ResultSet r=p.executeQuery()) {
                while(r.next()) {
                    Object[] row = new Object[]{r.getString(1),r.getString(2),r.getString(3),r.getString(4),r.getString(5),r.getString(6),r.getInt(7)};
                    ROWS.add(row);
                    java.sql.Timestamp completed = r.getTimestamp(8);
                    if (completed != null) COMPLETED_AT.put(r.getString(1), completed.toInstant().toString());
                }
            } catch(java.sql.SQLException e) { throw new RuntimeException("Cannot load document requests.",e); }
        }

        private static synchronized void saveRow(Object[] r, String completedAt) {
            try(java.sql.Connection c=Database.connect();
                java.sql.PreparedStatement p=c.prepareStatement("""
                  INSERT INTO document_requests(request_id,document_type,resident_name,purpose,request_date,status,quantity,completed_at)
                  VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(request_id) DO UPDATE SET document_type=EXCLUDED.document_type,
                  resident_name=EXCLUDED.resident_name,purpose=EXCLUDED.purpose,request_date=EXCLUDED.request_date,
                  status=EXCLUDED.status,quantity=EXCLUDED.quantity,completed_at=EXCLUDED.completed_at
                  """)) {
                for(int i=0;i<6;i++) p.setString(i+1,String.valueOf(r[i]));
                p.setInt(7, r.length > 6 ? Math.max(1, Integer.parseInt(String.valueOf(r[6]))) : 1);
                if (completedAt == null || completedAt.isBlank()) p.setTimestamp(8, null);
                else p.setTimestamp(8, java.sql.Timestamp.from(Instant.parse(completedAt)));
                p.executeUpdate();
            } catch(java.sql.SQLException e) { throw new RuntimeException("Cannot save document request.",e); }
        }

        /** Reload request rows and completion timestamps for updates made in other sessions. */
        static synchronized void reload() {
            List<Object[]> fresh = new ArrayList<>();
            Map<String, String> freshCompletedAt = new HashMap<>();
            try (java.sql.Connection c=Database.connect();
                 java.sql.PreparedStatement p=c.prepareStatement("SELECT request_id,document_type,resident_name,purpose,request_date,status,quantity,completed_at FROM document_requests ORDER BY request_id");
                 java.sql.ResultSet r=p.executeQuery()) {
                while(r.next()) {
                    fresh.add(new Object[]{r.getString(1),r.getString(2),r.getString(3),r.getString(4),r.getString(5),r.getString(6),r.getInt(7)});
                    java.sql.Timestamp completed = r.getTimestamp(8);
                    if (completed != null) freshCompletedAt.put(r.getString(1), completed.toInstant().toString());
                }
                ROWS.clear();
                ROWS.addAll(fresh);
                COMPLETED_AT.clear();
                COMPLETED_AT.putAll(freshCompletedAt);
            } catch(java.sql.SQLException e) {
                System.err.println("Could not refresh document requests: " + e.getMessage());
            }
        }

        static synchronized List<Object[]> forUser(User u) {
            List<Object[]> out=new ArrayList<>();
            for(Object[] r:ROWS) if(u.isAdmin() || String.valueOf(r[2]).equalsIgnoreCase(u.fullName)) out.add(r.clone());
            return out;
        }
        static synchronized List<Object[]> activeFor(User u) {
            List<Object[]> out = new ArrayList<>();
            for (Object[] r : forUser(u)) if (!"Completed".equalsIgnoreCase(String.valueOf(r[5]))) out.add(r);
            return out;
        }
        static synchronized List<Object[]> historyFor(User u) {
            List<Object[]> out = new ArrayList<>();
            for (Object[] r : forUser(u)) if ("Completed".equalsIgnoreCase(String.valueOf(r[5]))) out.add(r);
            return out;
        }
        static synchronized String completedAt(String requestId) { return COMPLETED_AT.get(requestId); }
        static synchronized int pendingFor(User u) {
            int n = 0;
            for (Object[] r : activeFor(u)) {
                String status = String.valueOf(r[5]);
                if ("For Acceptance".equalsIgnoreCase(status) || "Pending".equalsIgnoreCase(status)) n++;
            }
            return n;
        }

        static synchronized Object[] add(String type,String name,String purpose,String date,String status, int quantity) {
            int next=1;
            for(Object[] r:ROWS) {
                try { next=Math.max(next,Integer.parseInt(String.valueOf(r[0]).replace("REQ-",""))+1); }
                catch(Exception ignored) {}
            }
            Object[] row={String.format("REQ-%03d",next),type,name,purpose,date,status,Math.max(1, quantity)};
            String completedAt = "Completed".equalsIgnoreCase(status) ? Instant.now().truncatedTo(java.time.temporal.ChronoUnit.MICROS).toString() : null;
            saveRow(row, completedAt);
            ROWS.add(row);
            if (completedAt != null) COMPLETED_AT.put(String.valueOf(row[0]), completedAt);
            return row.clone();
        }

        static synchronized void update(String id,String type,String purpose,String status, int quantity) {
            for(Object[] r:ROWS) if(String.valueOf(r[0]).equals(id)) {
                boolean wasCompleted = "Completed".equalsIgnoreCase(String.valueOf(r[5]));
                boolean willBeCompleted = "Completed".equalsIgnoreCase(status);
                String completedAt = null;
                if (willBeCompleted) {
                    completedAt = wasCompleted ? COMPLETED_AT.get(id) : null;
                    if (completedAt == null) completedAt = Instant.now().truncatedTo(java.time.temporal.ChronoUnit.MICROS).toString();
                }
                r[1]=type; r[3]=purpose; r[5]=status; r[6]=Math.max(1, quantity);
                saveRow(r, completedAt);
                if (completedAt == null) COMPLETED_AT.remove(id);
                else COMPLETED_AT.put(id, completedAt);
                break;
            }
        }

        /** Return a resident-owned request only while it is waiting for staff acceptance. */
        static synchronized Object[] residentEditableRequest(String id, String residentName) {
            for (Object[] r : ROWS) {
                if (String.valueOf(r[0]).equals(id)
                        && String.valueOf(r[2]).equalsIgnoreCase(residentName)
                        && "For Acceptance".equalsIgnoreCase(String.valueOf(r[5]))) {
                    return r.clone();
                }
            }
            return null;
        }

        /** Residents may correct their own request details only before staff accepts it. */
        static synchronized boolean updateResidentRequest(String id, String residentName,
                String type, String purpose, int quantity) {
            Object[] existing = residentEditableRequest(id, residentName);
            if (existing == null) return false;
            update(id, type, purpose, String.valueOf(existing[5]), quantity);
            return true;
        }

        /** Move a request through the staff workflow without editing its details. */
        static synchronized void updateStatus(String id, String status) {
            for (Object[] r : ROWS) {
                if (String.valueOf(r[0]).equals(id)) {
                    update(id, String.valueOf(r[1]), String.valueOf(r[3]), status,
                            r.length > 6 ? Math.max(1, Integer.parseInt(String.valueOf(r[6]))) : 1);
                    return;
                }
            }
        }
    }

    enum Glyph { HOME, PEOPLE, DOC, REQUEST, HISTORY, HEART, CAP, MEGAPHONE, GEAR, LOCK }
 
    private static Path2D poly(boolean close, double... p) {
        Path2D path = new Path2D.Double();
        path.moveTo(p[0], p[1]);
        for (int i = 2; i < p.length; i += 2) path.lineTo(p[i], p[i + 1]);
        if (close) path.closePath();
        return path;
    }
 
    static class VectorIcon implements Icon {
        private final Glyph glyph;
        private final int size;
        private final Color color;
 
        VectorIcon(Glyph glyph, int size, Color color) {
            this.glyph = glyph; this.size = size; this.color = color;
        }
 
        @Override public int getIconWidth() { return size; }
        @Override public int getIconHeight() { return size; }
 
        @Override public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            g2.translate(x, y);
            g2.scale(size / 24.0, size / 24.0);
            g2.setColor(color);
            g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            switch (glyph) {
                case HOME:
                    g2.draw(poly(false, 3, 11, 12, 3, 21, 11));
                    g2.draw(poly(false, 5, 9.5, 5, 21, 19, 21, 19, 9.5));
                    g2.draw(poly(false, 10, 21, 10, 15, 14, 15, 14, 21));
                    break;
                case PEOPLE:
                    g2.draw(new Ellipse2D.Double(8, 3, 8, 8));
                    g2.draw(new Arc2D.Double(4, 14, 16, 14, 0, 180, Arc2D.OPEN));
                    break;
                case DOC:
                    g2.draw(new RoundRectangle2D.Double(5, 2, 14, 20, 4, 4));
                    g2.draw(poly(false, 8.5, 9, 15.5, 9));
                    g2.draw(poly(false, 8.5, 13, 15.5, 13));
                    g2.draw(poly(false, 8.5, 17, 12.5, 17));
                    break;
                case REQUEST:
                    g2.draw(new RoundRectangle2D.Double(5, 4, 14, 18, 4, 4));
                    g2.draw(new RoundRectangle2D.Double(9, 2, 6, 4, 2, 2));
                    g2.draw(poly(false, 8.5, 13.5, 11, 16, 16, 10.5));
                    break;
                case HEART: {
                    Path2D p = new Path2D.Double();
                    p.moveTo(12, 20);
                    p.curveTo(3, 14, 2, 7, 7, 5);
                    p.curveTo(10, 4, 12, 6, 12, 8);
                    p.curveTo(12, 6, 14, 4, 17, 5);
                    p.curveTo(22, 7, 21, 14, 12, 20);
                    g2.draw(p);
                    break;
                }
                case CAP: {
                    g2.draw(poly(true, 12, 4, 23, 9.5, 12, 15, 1, 9.5));
                    Path2D p = new Path2D.Double();
                    p.moveTo(6, 12.5);
                    p.lineTo(6, 17);
                    p.quadTo(12, 22, 18, 17);
                    p.lineTo(18, 12.5);
                    g2.draw(p);
                    break;
                }
                case MEGAPHONE:
                    g2.draw(poly(true, 3, 10, 8, 10, 18, 5, 18, 19, 8, 14, 3, 14));
                    g2.draw(poly(false, 21, 10, 21, 14));
                    g2.draw(poly(false, 8, 14, 9.5, 20));
                    break;
                case GEAR:
                    g2.draw(new Ellipse2D.Double(8.5, 8.5, 7, 7));
                    for (int k = 0; k < 8; k++) {
                        double a = Math.PI / 4 * k;
                        g2.draw(new Line2D.Double(12 + Math.cos(a) * 6.5, 12 + Math.sin(a) * 6.5,
                                12 + Math.cos(a) * 10, 12 + Math.sin(a) * 10));
                    }
                    break;
                case HISTORY:
                    g2.draw(new Ellipse2D.Double(3, 3, 18, 18));
                    g2.draw(new Line2D.Double(12, 6, 12, 12));
                    g2.draw(new Line2D.Double(12, 12, 16, 14));
                    break;
                case LOCK:
                    g2.draw(new Arc2D.Double(7, 2, 10, 14, 0, 180, Arc2D.OPEN));
                    g2.draw(new RoundRectangle2D.Double(5, 10, 14, 11, 3, 3));
                    g2.draw(new Ellipse2D.Double(11, 13.5, 2, 2));
                    g2.draw(new Line2D.Double(12, 15.5, 12, 18));
                    break;
            }
            g2.dispose();
        }
    }
 
    private static Glyph glyphFor(String page) {
        switch (page) {
            case "Home": return Glyph.HOME;
            case "History": return Glyph.HISTORY;
            case "Residents": return Glyph.PEOPLE;
            case "My Profile": return Glyph.PEOPLE;
            case "Settings": return Glyph.GEAR;
            case "Notifications": return Glyph.MEGAPHONE;
            case "Barangay Documents": return Glyph.DOC;
            case "Document Requests": return Glyph.REQUEST;
            case "Announcements": return Glyph.MEGAPHONE;
            default: return Glyph.GEAR;
        }
    }
 
    /**
     * Barangay photo. If a photo named barangay.jpg / barangay.jpeg / barangay.png sits next to the
     * program, it is used (cropped to fit). Otherwise a drawn picture of a barangay hall is shown.
     */
    static class BarangayPhoto extends JComponent {
        private static BufferedImage cached;
        private static boolean tried;
        private final int arc;
        private final String title, subtitle;
        private float focusY = 0.5f;   // which part of a tall photo to show (0 = top, 1 = bottom)
 
        BarangayPhoto(int w, int h, int arc, String title, String subtitle) {
            this.arc = arc; this.title = title; this.subtitle = subtitle;
            setPreferredSize(new Dimension(w, h));
        }
 
        BarangayPhoto focus(float y) { this.focusY = y; return this; }

        static BufferedImage load() {
            if (!tried) {
                tried = true;
                for (String n : new String[]{"barangay.jpg", "barangay.jpeg", "barangay.png"}) {
                    java.io.File f = new java.io.File(n);
                    if (f.exists()) {
                        try { cached = javax.imageio.ImageIO.read(f); } catch (Exception ignored) { }
                        if (cached != null) break;
                    }
                }
            }
            return cached;
        }
 
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            int w = getWidth(), h = getHeight();
            g2.setClip(new RoundRectangle2D.Double(0, 0, w, h, arc, arc));
            BufferedImage img = load();
            if (img != null) {
                double s = Math.max((double) w / img.getWidth(), (double) h / img.getHeight());
                int dw = (int) (img.getWidth() * s), dh = (int) (img.getHeight() * s);
                g2.drawImage(img, (w - dw) / 2, (int) ((h - dh) * focusY), dw, dh, null);
            } else {
                paintScene(g2, w, h);
            }
            if (title != null) {
                g2.setPaint(new GradientPaint(0, 0, new Color(5, 36, 80, 225), w * 0.8f, 0, new Color(5, 36, 80, 0)));
                g2.fillRect(0, 0, w, h);
                g2.setColor(Color.WHITE);
                g2.setFont(font(Font.BOLD, 28));
                g2.drawString(title, 30, h / 2 - 2);
                g2.setFont(font(Font.PLAIN, 15));
                g2.setColor(new Color(215, 233, 249));
                g2.drawString(subtitle, 30, h / 2 + 26);
            }
            g2.setClip(null);
            g2.setColor(new Color(255, 255, 255, 210));
            g2.setStroke(new BasicStroke(2f));
            g2.drawRoundRect(1, 1, w - 3, h - 3, arc, arc);
            g2.dispose();
        }
 
        private static void tree(Graphics2D g2, int x, int base, int size) {
            g2.setColor(new Color(105, 70, 40));
            g2.fillRect(x - size / 12, base - size / 2, Math.max(2, size / 6), size / 2);
            g2.setColor(new Color(46, 125, 62));
            g2.fillOval(x - size / 2, base - size - size / 6, size, size);
            g2.setColor(new Color(64, 150, 78));
            g2.fillOval(x - size / 3, base - size - size / 4, size * 2 / 3, size * 2 / 3);
        }
 
        static void paintScene(Graphics2D g2, int w, int h) {
            g2.setPaint(new GradientPaint(0, 0, new Color(96, 174, 236), 0, h * 0.75f, new Color(218, 240, 253)));
            g2.fillRect(0, 0, w, h);
            g2.setColor(new Color(255, 255, 255, 215));
            g2.fillOval((int) (w * 0.08), (int) (h * 0.14), (int) (w * 0.16), (int) (h * 0.13));
            g2.fillOval((int) (w * 0.13), (int) (h * 0.10), (int) (w * 0.14), (int) (h * 0.14));
            g2.fillOval((int) (w * 0.62), (int) (h * 0.2), (int) (w * 0.14), (int) (h * 0.11));
            g2.setColor(new Color(255, 226, 135));
            g2.fillOval((int) (w * 0.84), (int) (h * 0.07), (int) (h * 0.2), (int) (h * 0.2));
            g2.setColor(new Color(124, 188, 134));
            g2.fillOval(-w / 6, (int) (h * 0.52), (int) (w * 0.6), (int) (h * 0.5));
            g2.setColor(new Color(100, 168, 114));
            g2.fillOval((int) (w * 0.42), (int) (h * 0.58), (int) (w * 0.8), (int) (h * 0.5));
            int ground = (int) (h * 0.78);
            g2.setColor(new Color(84, 158, 92));
            g2.fillRect(0, ground, w, h - ground);
            g2.setColor(new Color(182, 175, 164));
            g2.fillPolygon(new int[]{(int) (w * 0.46), (int) (w * 0.54), (int) (w * 0.68), (int) (w * 0.32)},
                    new int[]{ground, ground, h, h}, 4);
 
            int bw = (int) Math.min(w * 0.46, h * 1.55), bh = (int) (h * 0.34);
            int bx = (w - bw) / 2, by = ground - bh;
            tree(g2, bx - bw / 6, ground, (int) (h * 0.36));
            tree(g2, bx + bw + bw / 3, ground, (int) (h * 0.30));
 
            g2.setColor(new Color(252, 248, 234));
            g2.fillRect(bx, by, bw, bh);
            g2.setColor(new Color(196, 56, 56));
            g2.fillPolygon(new int[]{bx - bw / 12, bx + bw + bw / 12, (int) (bx + bw * 0.88), (int) (bx + bw * 0.12)},
                    new int[]{by, by, (int) (by - bh * 0.45), (int) (by - bh * 0.45)}, 4);
            g2.setColor(NAVY);
            g2.fillRoundRect(bx + bw / 5, by + bh / 10, bw * 3 / 5, Math.max(6, bh / 5), 6, 6);
            if (bh >= 44) {
                g2.setColor(Color.WHITE);
                g2.setFont(font(Font.BOLD, Math.max(8, bh / 7)));
                FontMetrics fm = g2.getFontMetrics();
                String t = "BARANGAY HALL";
                g2.drawString(t, bx + (bw - fm.stringWidth(t)) / 2, by + bh / 10 + (Math.max(6, bh / 5) + fm.getAscent()) / 2 - 1);
            }
            g2.setColor(new Color(125, 80, 46));
            g2.fillRect(bx + bw / 2 - bw / 14, by + bh / 2, bw / 7, bh / 2);
            g2.setColor(new Color(150, 206, 240));
            g2.fillRect(bx + bw / 10, by + bh / 2, bw / 6, bh / 4);
            g2.fillRect(bx + bw - bw / 10 - bw / 6, by + bh / 2, bw / 6, bh / 4);
 
            int px = bx + bw + bw / 10, top = (int) (by - bh * 0.95);
            g2.setColor(new Color(95, 95, 95));
            g2.fillRect(px, top, 2, ground - top);
            int fw = Math.max(14, bw / 4), fh = fw * 2 / 3;
            g2.setColor(new Color(0, 56, 168));
            g2.fillRect(px + 2, top, fw, fh / 2);
            g2.setColor(new Color(206, 17, 38));
            g2.fillRect(px + 2, top + fh / 2, fw, fh / 2);
            g2.setColor(Color.WHITE);
            g2.fillPolygon(new int[]{px + 2, px + 2, px + 2 + fh * 4 / 5},
                    new int[]{top, top + fh, top + fh / 2}, 3);
        }
    }
 
    /** Small circular icon badge used on the dashboard cards. */
    static class IconBadge extends JComponent {
        private final Glyph glyph;
        private final Color color;
 
        IconBadge(Glyph glyph, Color color) {
            this.glyph = glyph; this.color = color;
            Dimension d = new Dimension(48, 48);
            setPreferredSize(d); setMinimumSize(d); setMaximumSize(d);
            setAlignmentX(Component.LEFT_ALIGNMENT);
        }
 
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            g2.setColor(color);
            g2.fill(new Ellipse2D.Double(0, 0, 47, 47));
            new VectorIcon(glyph, 24, Color.WHITE).paintIcon(this, g2, 12, 12);
            g2.dispose();
        }
    }
 
    /** Window / taskbar icon. */
    private static Image windowIcon() {
        BufferedImage img = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        aa(g2);
        g2.setClip(new RoundRectangle2D.Double(0, 0, 64, 64, 16, 16));
        BarangayPhoto.paintScene(g2, 64, 64);
        g2.dispose();
        return img;
    }
 
    // =====================================================================
    //  Custom painted components
    // =====================================================================
    static class GradientPanel extends JPanel {
        private final Color c1, c2;
        private final boolean vertical;
 
        GradientPanel(LayoutManager lm, Color c1, Color c2, boolean vertical) {
            super(lm);
            this.c1 = c1; this.c2 = c2; this.vertical = vertical;
            setOpaque(false);
        }
 
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setPaint(vertical ? new GradientPaint(0, 0, c1, 0, getHeight(), c2)
                    : new GradientPaint(0, 0, c1, getWidth(), 0, c2));
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.dispose();
            super.paintComponent(g);
        }
    }
 
    static class RoundPanel extends JPanel {
        private final int arc;
        private final Color fill, border;
        private final boolean shadow;
 
        RoundPanel(LayoutManager lm, int arc, Color fill, Color border, boolean shadow) {
            super(lm);
            this.arc = arc; this.fill = fill; this.border = border; this.shadow = shadow;
            setOpaque(false);
        }
 
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            int w = getWidth() - 3, h = getHeight() - 3;
            if (shadow) {
                g2.setColor(new Color(10, 40, 80, 18));
                g2.fillRoundRect(1, 3, w, h, arc, arc);
            }
            g2.setColor(fill);
            g2.fillRoundRect(0, 0, w, h, arc, arc);
            if (border != null) {
                g2.setColor(border);
                g2.drawRoundRect(0, 0, w, h, arc, arc);
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }
 
    static class PillButton extends JButton {
        PillButton(String text) {
            super(text);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setRolloverEnabled(true);
            setForeground(Color.WHITE);
            setFont(font(Font.BOLD, 13));
            setBorder(new EmptyBorder(9, 18, 9, 18));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }
 
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            boolean hot = getModel().isRollover() || getModel().isArmed();
            Color top = hot ? new Color(30, 140, 235) : new Color(0, 125, 225);
            Color bottom = hot ? new Color(0, 110, 210) : new Color(0, 92, 182);
            g2.setPaint(new GradientPaint(0, 0, top, 0, getHeight(), bottom));
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
            g2.setFont(getFont());
            g2.setColor(Color.WHITE);
            FontMetrics fm = g2.getFontMetrics();
            int tx = (getWidth() - fm.stringWidth(getText())) / 2;
            int ty = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
            g2.drawString(getText(), tx, ty);
            g2.dispose();
        }
    }
 
    /** Standard rectangular action button used by the Settings page. */
    static class SettingsButton extends JButton {
        private final boolean primary;

        SettingsButton(String text, boolean primary) {
            super(text);
            this.primary = primary;
            setFont(font(Font.BOLD, 13));
            setFocusPainted(false);
            setContentAreaFilled(true);
            setOpaque(true);
            setRolloverEnabled(true);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setBorder(new CompoundBorder(
                    new LineBorder(primary ? BLUE.darker() : CARD_BORDER, 1, true),
                    new EmptyBorder(8, 16, 8, 16)));
            setPreferredSize(new Dimension(184, 40));
            setMinimumSize(new Dimension(150, 38));
            applyColors();
            addChangeListener(e -> applyColors());
        }

        private void applyColors() {
            boolean hot = getModel().isRollover() || getModel().isArmed();
            if (primary) {
                setBackground(hot ? new Color(24, 135, 225) : BLUE);
                setForeground(Color.WHITE);
            } else {
                setBackground(hot
                        ? (darkMode ? new Color(32, 57, 88) : new Color(220, 234, 250))
                        : (darkMode ? new Color(18, 34, 57) : new Color(239, 245, 252)));
                setForeground(TXT);
            }
        }
    }

    /** Compact application-style on/off switch for notification preferences. */
    static class SettingsSwitch extends JToggleButton {
        SettingsSwitch(boolean selected) {
            setSelected(selected);
            setPreferredSize(new Dimension(54, 30));
            setMinimumSize(new Dimension(54, 30));
            setMaximumSize(new Dimension(54, 30));
            setBorderPainted(false);
            setContentAreaFilled(false);
            setFocusPainted(false);
            setOpaque(false);
            setText("");
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setToolTipText("Turn notifications on or off");
            getAccessibleContext().setAccessibleName("Enable notifications");
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            int trackX = 2, trackY = 5, trackW = getWidth() - 4, trackH = getHeight() - 10;
            Color track = isSelected() ? BLUE : (darkMode ? new Color(75, 91, 112) : new Color(190, 201, 215));
            g2.setColor(track);
            g2.fillRoundRect(trackX, trackY, trackW, trackH, trackH, trackH);
            int d = trackH - 6;
            int thumbX = isSelected() ? trackX + trackW - d - 3 : trackX + 3;
            g2.setColor(Color.WHITE);
            g2.fillOval(thumbX, trackY + 3, d, d);
            if (isFocusOwner()) {
                g2.setColor(LINK);
                g2.setStroke(new BasicStroke(1.3f));
                g2.drawRoundRect(trackX - 1, trackY - 1, trackW + 2, trackH + 2, trackH, trackH);
            }
            g2.dispose();
        }
    }

    /** Text-only button that looks like a link. */
    static class LinkButton extends JButton {
        LinkButton(String text, Color color, int size) {
            super(text);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setForeground(color);
            setFont(font(Font.BOLD, size));
            setBorder(new EmptyBorder(2, 4, 2, 4));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }
    }
 
    /** One half of the "Resident | Admin" switch on the sign-in screen. */
    static class RoleTab extends JButton {
        private boolean selected;
 
        RoleTab(String text) {
            super(text);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setFont(font(Font.BOLD, 13));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }
 
        void setSelectedTab(boolean s) { selected = s; repaint(); }
 
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            g2.setColor(selected ? BLUE : new Color(229, 241, 251));
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
            g2.setFont(getFont());
            g2.setColor(selected ? Color.WHITE : NAVY);
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(getText(), (getWidth() - fm.stringWidth(getText())) / 2,
                    (getHeight() - fm.getHeight()) / 2 + fm.getAscent());
            g2.dispose();
        }
    }
 
    static class NavButton extends JButton {
        private final Glyph glyph;
        private boolean selected;
        private boolean compact;
        private int badgeCount;
 
        NavButton(String text, Glyph glyph) {
            super(text);
            this.glyph = glyph;
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setRolloverEnabled(true);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setAlignmentX(Component.LEFT_ALIGNMENT);
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
            setPreferredSize(new Dimension(200, 44));
            setToolTipText(text);
        }
 
        void setSelectedPage(boolean s) { selected = s; repaint(); }
        void setCompact(boolean value) { compact = value; revalidate(); repaint(); }

        @Override public Dimension getPreferredSize() {
            return new Dimension(compact ? 44 : 200, 44);
        }

        @Override public Dimension getMinimumSize() {
            return new Dimension(compact ? 40 : 150, 44);
        }

        void setBadgeCount(int count) {
            badgeCount = Math.max(0, count);
            repaint();
        }
 
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            int w = getWidth(), h = getHeight();
            if (selected) {
                g2.setPaint(new GradientPaint(0, 0, new Color(0, 135, 235), w, 0, new Color(0, 98, 195)));
                g2.fillRoundRect(0, 0, w, h, 14, 14);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 11, 4, h - 22, 4, 4);
            } else if (getModel().isRollover()) {
                g2.setColor(new Color(255, 255, 255, 32));
                g2.fillRoundRect(0, 0, w, h, 14, 14);
            }
            int iconX = compact ? Math.max(0, (w - 20) / 2) : 16;
            new VectorIcon(glyph, 20, Color.WHITE).paintIcon(this, g2, iconX, (h - 20) / 2);
            if (!compact) {
                g2.setFont(font(Font.BOLD, 14));
                g2.setColor(selected ? Color.WHITE : new Color(215, 232, 247));
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(getText(), 48, (h - fm.getHeight()) / 2 + fm.getAscent());
            }

            // Red circular counter for pending/visible notifications. Hide it when empty.
            if ("Announcements".equals(getText()) && badgeCount > 0) {
                int diameter = 9;
                int bx = compact ? Math.max(0, w - diameter - 3) : w - diameter - 15;
                int by = (h - diameter) / 2;
                g2.setColor(new Color(220, 38, 38));
                g2.fillOval(bx, by, diameter, diameter);
            } else if ("Notifications".equals(getText()) && badgeCount > 0) {
                String countText = badgeCount > 99 ? "99+" : String.valueOf(badgeCount);
                int diameter = badgeCount > 99 ? 18 : 16;
                int bx = compact ? Math.max(0, w - diameter - 3) : w - diameter - 12;
                int by = (h - diameter) / 2;
                g2.setColor(new Color(255, 255, 255, 235));
                g2.fillOval(bx - 1, by - 1, diameter + 2, diameter + 2);
                g2.setColor(new Color(220, 38, 38));
                g2.fillOval(bx, by, diameter, diameter);
                g2.setFont(font(Font.BOLD, badgeCount > 99 ? 6 : 8));
                g2.setColor(Color.WHITE);
                FontMetrics badgeFm = g2.getFontMetrics();
                g2.drawString(countText, bx + (diameter - badgeFm.stringWidth(countText)) / 2,
                        by + (diameter - badgeFm.getHeight()) / 2 + badgeFm.getAscent());
            }
            g2.dispose();
        }
    }
 
    // =====================================================================
    //  Table renderers (themed)
    // =====================================================================
    private static Color[] palette(String status) {
        switch (status) {
            case "Active": case "Available": case "Completed":
                return new Color[]{new Color(18, 92, 62), new Color(160, 245, 196)};
            case "Upcoming": case "Processing":
                return new Color[]{new Color(20, 72, 135), new Color(170, 215, 255)};
            case "Pending": case "For Acceptance": case "Ongoing": case "Ask staff":
                return new Color[]{new Color(122, 82, 10), new Color(255, 214, 140)};
            case "Inactive":
                return new Color[]{new Color(52, 62, 76), new Color(195, 205, 215)};
            default:
                return null;
        }
    }
 
    static class BaseRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
            super.getTableCellRendererComponent(t, v, sel, false, r, c);
            setBorder(new EmptyBorder(0, 12, 0, 12));
            setFont(font(Font.PLAIN, 13));
            setForeground(TXT);
            setBackground(sel ? SELECT : (r % 2 == 0 ? ROW_A : ROW_B));
            return this;
        }
    }
 
    static class ActionRenderer extends BaseRenderer {
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
            super.getTableCellRendererComponent(t, v, sel, foc, r, c);
            setForeground(LINK);
            setFont(font(Font.BOLD, 13));
            return this;
        }
    }

    /** Consistent center alignment for the compact ID, date, and quantity columns. */
    static class CenteredRenderer extends BaseRenderer {
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
            super.getTableCellRendererComponent(t, v, sel, foc, r, c);
            setHorizontalAlignment(SwingConstants.CENTER);
            return this;
        }
    }

    /** Button-style action shown for each active document request. */
    static class RequestActionRenderer implements javax.swing.table.TableCellRenderer {
        private final JPanel panel = new JPanel(new GridBagLayout());
        private final JButton button = new JButton();

        RequestActionRenderer() {
            panel.setOpaque(true);
            button.setFont(font(Font.BOLD, 12));
            button.setForeground(Color.WHITE);
            button.setFocusPainted(false);
            button.setContentAreaFilled(true);
            button.setOpaque(true);
            button.setMargin(new Insets(5, 10, 5, 10));
            button.setPreferredSize(new Dimension(98, 30));
            button.setMinimumSize(new Dimension(90, 28));
            button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            GridBagConstraints gc = new GridBagConstraints();
            gc.anchor = GridBagConstraints.CENTER;
            gc.insets = new Insets(2, 4, 2, 4);
            gc.weightx = 1;
            gc.fill = GridBagConstraints.NONE;
            panel.add(button, gc);
        }

        @Override public Component getTableCellRendererComponent(JTable table, Object value,
                boolean selected, boolean focused, int row, int column) {
            String action = value == null ? "" : value.toString();
            panel.setBackground(selected ? SELECT : (row % 2 == 0 ? ROW_A : ROW_B));
            button.setText(action);
            button.setVisible(!action.isBlank());
            Color fill = "Complete".equalsIgnoreCase(action) ? new Color(18, 125, 78)
                    : ("Edit".equalsIgnoreCase(action) ? new Color(76, 86, 105) : new Color(0, 105, 190));
            button.setBackground(fill);
            button.setBorder(new CompoundBorder(new LineBorder(fill.darker(), 1, true),
                    new EmptyBorder(2, 5, 2, 5)));
            return panel;
        }
    }

    static class Pill extends JLabel {
        private Color fill = Color.LIGHT_GRAY;
 
        Pill() {
            setOpaque(false);
            setFont(font(Font.BOLD, 12));
            setBorder(new EmptyBorder(3, 12, 3, 12));
        }
 
        void setFill(Color c) { fill = c; }
 
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            g2.setColor(fill);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
            g2.dispose();
            super.paintComponent(g);
        }
    }
 
    static class PillRenderer implements javax.swing.table.TableCellRenderer {
        private final JPanel panel = new JPanel(new GridBagLayout());
        private final Pill pill = new Pill();
        private final BaseRenderer fallback = new BaseRenderer();
 
        PillRenderer() { this(false); }

        PillRenderer(boolean centered) {
            GridBagConstraints gc = new GridBagConstraints();
            gc.anchor = centered ? GridBagConstraints.CENTER : GridBagConstraints.WEST;
            gc.insets = centered ? new Insets(0, 4, 0, 4) : new Insets(0, 10, 0, 0);
            gc.weightx = 1;
            panel.add(pill, gc);
        }
 
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
            String text = v == null ? "" : v.toString();
            Color[] pal = palette(text);
            if (pal == null) return fallback.getTableCellRendererComponent(t, v, sel, foc, r, c);
            panel.setBackground(sel ? SELECT : (r % 2 == 0 ? ROW_A : ROW_B));
            pill.setText(text);
            pill.setFill(pal[0]);
            pill.setForeground(pal[1]);
            return panel;
        }
    }
 
    // =====================================================================
    //  Sign-in window (resident log in / resident sign up / admin log in)
    // =====================================================================
 
    static class LoginFrame extends JFrame {
        // Colors used only on the sign-in screen (readable on a dark background)
        private static final Color G_TOP    = new Color(0, 111, 210);   // blue
        private static final Color G_BOTTOM = new Color(3, 8, 18);      // near black
        private static final Color TXT      = Color.WHITE;
        private static final Color TXT_SOFT = new Color(190, 214, 240);
        private static final Color LINK     = new Color(120, 195, 255);
        private static final Color ERR      = new Color(255, 130, 140);
 
        private final CardLayout forms = new CardLayout();
        private final JPanel formCards = new JPanel(forms);
        private boolean adminMode = false;
        private int failedAttempts = 0;
        private long lockedUntil = 0;
 
        private final RoleTab residentTab = new RoleTab("Resident Sign In");
        private final RoleTab adminTab = new RoleTab("Staff Log In");
        private final JLabel heading = new JLabel();
        private final JLabel subheading = new JLabel();
        private final JTextField userField = new JTextField();
        private final JPasswordField passField = new JPasswordField();
        private final JLabel loginError = new JLabel(" ");
        private final PillButton loginButton = new PillButton("Sign In");
        private final JPanel signupRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        private final JPanel forgotRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
 
        // sign-up fields
        private final JTextField suName = new JTextField();
        private final JComboBox<String> suPurok = new JComboBox<>(new String[]{"Purok 1", "Purok 2", "Purok 3", "Purok 4",
                "Purok 5", "Purok 6", "Purok 7", "Purok 8"});
        private final JTextField suContact = new JTextField();
        private final JTextField suAddress = new JTextField();
        private final JTextField suUser = new JTextField();
        private final JPasswordField suPass = new JPasswordField();
        private final JPasswordField suConfirm = new JPasswordField();
        private final JLabel signupError = new JLabel(" ");
        private final PillButton signupButton = new PillButton("Create Account");
 
        LoginFrame() {
            setTitle("Baryo Konek — Resident Sign In / Staff Log In");
            setIconImage(windowIcon());
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            Rectangle usableScreen = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
            int frameWidth = Math.min(1160, Math.max(820, usableScreen.width - 40));
            int frameHeight = Math.min(780, Math.max(620, usableScreen.height - 40));
            setMinimumSize(new Dimension(800, 600));
            setSize(frameWidth, frameHeight);
            setLocationRelativeTo(null);

            // Calm dark background around a two-column login card, inspired by the supplied reference.
            GradientPanel background = new GradientPanel(new GridBagLayout(),
                    new Color(15, 35, 62), new Color(5, 12, 25), true);
            setContentPane(background);

            JPanel splitCard = new JPanel(new GridLayout(1, 2, 0, 0));
            splitCard.setOpaque(true);
            splitCard.setBackground(Color.WHITE);
            splitCard.setBorder(new CompoundBorder(
                    new LineBorder(new Color(220, 230, 241), 1, true),
                    new EmptyBorder(0, 0, 0, 0)));
            splitCard.setPreferredSize(new Dimension(
                    Math.min(1040, frameWidth - 72), Math.min(600, frameHeight - 88)));

            // Left visual/branding panel. The existing barangay.jpg is used as the background image.
            JPanel brandPanel = new JPanel() {
                @Override protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    Graphics2D g2 = (Graphics2D) g.create();
                    aa(g2);
                    g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                    BufferedImage image = BarangayPhoto.load();
                    if (image != null) {
                        double scale = Math.max((double) getWidth() / image.getWidth(),
                                (double) getHeight() / image.getHeight());
                        int iw = (int) Math.ceil(image.getWidth() * scale);
                        int ih = (int) Math.ceil(image.getHeight() * scale);
                        g2.drawImage(image, (getWidth() - iw) / 2, (getHeight() - ih) / 2, iw, ih, null);
                    } else {
                        BarangayPhoto.paintScene(g2, getWidth(), getHeight());
                    }
                    g2.setPaint(new GradientPaint(0, 0, new Color(5, 34, 70, 215),
                            getWidth(), getHeight(), new Color(4, 24, 52, 165)));
                    g2.fillRect(0, 0, getWidth(), getHeight());
                    g2.dispose();
                }
            };
            brandPanel.setOpaque(false);
            brandPanel.setLayout(new BorderLayout());
            brandPanel.setBorder(new EmptyBorder(34, 34, 28, 30));

            JPanel brandContent = new JPanel();
            brandContent.setOpaque(false);
            brandContent.setLayout(new BoxLayout(brandContent, BoxLayout.Y_AXIS));
            JLabel brandName = new JLabel("Baryo Konek", new VectorIcon(Glyph.PEOPLE, 28, Color.WHITE), SwingConstants.LEFT);
            brandName.setIconTextGap(10);
            brandName.setFont(font(Font.BOLD, 18));
            brandName.setForeground(Color.WHITE);
            brandName.setAlignmentX(Component.LEFT_ALIGNMENT);
            brandContent.add(brandName);
            brandContent.add(Box.createVerticalStrut(42));

            JLabel communityTitle = new JLabel("Barangay Indangan");
            communityTitle.setFont(font(Font.BOLD, 27));
            communityTitle.setForeground(Color.WHITE);
            communityTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
            brandContent.add(communityTitle);
            brandContent.add(Box.createVerticalStrut(8));
            JLabel communityLine = new JLabel("<html>A stronger community,<br>a brighter future.</html>");
            communityLine.setFont(font(Font.PLAIN, 15));
            communityLine.setForeground(new Color(235, 244, 255));
            communityLine.setAlignmentX(Component.LEFT_ALIGNMENT);
            brandContent.add(communityLine);
            brandContent.add(Box.createVerticalStrut(30));

            JPanel features = new JPanel();
            features.setOpaque(false);
            features.setLayout(new BoxLayout(features, BoxLayout.Y_AXIS));
            addBrandFeature(features, Glyph.PEOPLE, "Stay Informed");
            addBrandFeature(features, Glyph.DOC, "Request Documents");
            addBrandFeature(features, Glyph.HEART, "Access Health Services");
            addBrandFeature(features, Glyph.CAP, "Explore Education Opportunities");
            brandContent.add(features);
            brandContent.add(Box.createVerticalGlue());

            JLabel footer = new JLabel("Barangay Indangan   •   Community   •   Service   •   Progress");
            footer.setFont(font(Font.PLAIN, 10));
            footer.setForeground(new Color(225, 239, 255));
            footer.setAlignmentX(Component.LEFT_ALIGNMENT);
            brandContent.add(footer);
            brandPanel.add(brandContent, BorderLayout.CENTER);
            splitCard.add(brandPanel);

            // Right-side clean white sign-in form.
            JPanel rightPanel = new JPanel(new BorderLayout());
            rightPanel.setOpaque(true);
            rightPanel.setBackground(Color.WHITE);
            rightPanel.setBorder(new EmptyBorder(38, 42, 30, 42));

            JPanel inner = new JPanel();
            inner.setOpaque(false);
            inner.setLayout(new BoxLayout(inner, BoxLayout.Y_AXIS));
            inner.setAlignmentX(Component.LEFT_ALIGNMENT);

            heading.setFont(font(Font.BOLD, 27));
            heading.setForeground(new Color(28, 43, 64));
            heading.setAlignmentX(Component.LEFT_ALIGNMENT);
            heading.setHorizontalAlignment(SwingConstants.CENTER);
            heading.setMaximumSize(new Dimension(380, 40));
            subheading.setFont(font(Font.PLAIN, 12));
            subheading.setForeground(new Color(105, 120, 140));
            subheading.setAlignmentX(Component.LEFT_ALIGNMENT);
            subheading.setHorizontalAlignment(SwingConstants.CENTER);
            subheading.setMaximumSize(new Dimension(380, 42));
            inner.add(heading);
            inner.add(Box.createVerticalStrut(4));
            inner.add(subheading);
            inner.add(Box.createVerticalStrut(22));

            JPanel tabs = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
            tabs.setOpaque(false);
            tabs.setAlignmentX(Component.LEFT_ALIGNMENT);
            tabs.setMaximumSize(new Dimension(380, 40));
            tabs.setPreferredSize(new Dimension(380, 40));
            residentTab.setPreferredSize(new Dimension(182, 38));
            adminTab.setPreferredSize(new Dimension(182, 38));
            tabs.add(residentTab);
            tabs.add(Box.createHorizontalStrut(8));
            tabs.add(adminTab);
            residentTab.addActionListener(e -> setRole(false));
            adminTab.addActionListener(e -> setRole(true));
            inner.add(tabs);
            inner.add(Box.createVerticalStrut(10));

            formCards.setOpaque(false);
            formCards.setAlignmentX(Component.LEFT_ALIGNMENT);
            formCards.setMaximumSize(new Dimension(380, Integer.MAX_VALUE));
            formCards.add(buildLoginForm(), "login");
            formCards.add(buildSignupForm(), "signup");
            inner.add(formCards);
            inner.add(Box.createVerticalGlue());

            rightPanel.add(inner, BorderLayout.NORTH);
            splitCard.add(rightPanel);

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.weightx = 1.0;
            gbc.weighty = 1.0;
            gbc.anchor = GridBagConstraints.CENTER;
            gbc.fill = GridBagConstraints.NONE;
            gbc.insets = new Insets(20, 20, 20, 20);
            background.add(splitCard, gbc);

            setRole(false);
        }

        private void addBrandFeature(JPanel parent, Glyph glyph, String text) {
            JLabel item = new JLabel(text, new VectorIcon(glyph, 18, Color.WHITE), SwingConstants.LEFT);
            item.setIconTextGap(12);
            item.setFont(font(Font.PLAIN, 13));
            item.setForeground(new Color(242, 247, 255));
            item.setAlignmentX(Component.LEFT_ALIGNMENT);
            item.setBorder(new EmptyBorder(0, 0, 16, 0));
            parent.add(item);
        }

        /** Centered, wrapped subheading text. */
        private void setSub(String text) {
            subheading.setText("<html><div style='text-align:center;width:340px'>" + text + "</div></html>");
        }
 
        private JLabel label(String text) {
            JLabel l = new JLabel(text);
            l.setFont(font(Font.BOLD, 12));
            l.setForeground(new Color(44, 59, 78));
            l.setAlignmentX(Component.LEFT_ALIGNMENT);
            l.setHorizontalAlignment(SwingConstants.LEFT);
            l.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
            l.setBorder(new EmptyBorder(10, 0, 4, 0));
            return l;
        }
 
        private <T extends JComponent> T sized(T c) {
            c.setAlignmentX(Component.LEFT_ALIGNMENT);
            c.setPreferredSize(new Dimension(380, 38));
            c.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
            return c;
        }
 
        private void styleField(JTextField f) {
            f.setFont(font(Font.PLAIN, 14));
            f.setForeground(INK);
            f.setBackground(Color.WHITE);
            f.setCaretColor(INK);
            f.setBorder(new CompoundBorder(new LineBorder(new Color(205, 216, 229), 1, true), new EmptyBorder(7, 10, 7, 10)));
            sized(f);
        }

        /** Input field with a small leading icon, matching the supplied login reference. */
        private JComponent iconField(JTextField field, Glyph glyph) {
            field.setFont(font(Font.PLAIN, 14));
            field.setForeground(INK);
            field.setBackground(Color.WHITE);
            field.setCaretColor(INK);
            field.setBorder(new EmptyBorder(6, 2, 6, 2));
            JPanel wrap = new JPanel(new BorderLayout(9, 0));
            wrap.setOpaque(true);
            wrap.setBackground(Color.WHITE);
            wrap.setBorder(new CompoundBorder(new LineBorder(new Color(210, 221, 233), 1, true),
                    new EmptyBorder(1, 10, 1, 10)));
            JLabel icon = new JLabel(new VectorIcon(glyph, 17, new Color(112, 128, 148)));
            wrap.add(icon, BorderLayout.WEST);
            wrap.add(field, BorderLayout.CENTER);
            wrap.setAlignmentX(Component.LEFT_ALIGNMENT);
            wrap.setPreferredSize(new Dimension(380, 42));
            wrap.setMinimumSize(new Dimension(260, 42));
            wrap.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            return wrap;
        }
 
        private void styleError(JLabel l) {
            l.setFont(font(Font.BOLD, 12));
            l.setForeground(new Color(190, 35, 50));
            l.setAlignmentX(Component.LEFT_ALIGNMENT);
            l.setBorder(new EmptyBorder(8, 0, 4, 0));
            l.setHorizontalAlignment(SwingConstants.LEFT);
            l.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        }
 
        private void styleButton(PillButton b) {
            b.setAlignmentX(Component.LEFT_ALIGNMENT);
            b.setPreferredSize(new Dimension(380, 44));
            b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        }
 
        private JComponent buildLoginForm() {
            JPanel p = new JPanel();
            p.setOpaque(false);
            p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
            p.setAlignmentX(Component.LEFT_ALIGNMENT);
            p.setMaximumSize(new Dimension(380, Integer.MAX_VALUE));
            p.setPreferredSize(new Dimension(380, 360));
            passField.setEchoChar('\u2022');

            p.add(label("Username"));
            p.add(iconField(userField, Glyph.PEOPLE));
            p.add(label("Password"));
            p.add(iconField(passField, Glyph.LOCK));

            JCheckBox show = new JCheckBox("Show password");
            show.setOpaque(false);
            show.setFont(font(Font.PLAIN, 12));
            show.setForeground(new Color(89, 105, 126));
            show.setFocusPainted(false);
            show.setAlignmentX(Component.LEFT_ALIGNMENT);
            show.setHorizontalAlignment(SwingConstants.LEFT);
            show.setMaximumSize(new Dimension(220, 26));
            show.addActionListener(e -> passField.setEchoChar(show.isSelected() ? (char) 0 : '\u2022'));

            LinkButton forgot = new LinkButton("Forgot password?", new Color(42, 103, 174), 11);
            forgot.addActionListener(e -> {
                if (adminMode) {
                    JOptionPane.showMessageDialog(this,
                            "Please contact the Barangay Captain or IT officer to reset a staff account password.",
                            "Password Reset — Staff", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this,
                            "Please visit the Barangay Hall with a valid ID so staff can verify your identity\n"
                                    + "and help you reset your resident account password.",
                            "Password Reset — Resident", JOptionPane.INFORMATION_MESSAGE);
                }
            });
            JPanel options = new JPanel(new BorderLayout());
            options.setOpaque(false);
            options.setAlignmentX(Component.LEFT_ALIGNMENT);
            options.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
            options.add(show, BorderLayout.WEST);
            options.add(forgot, BorderLayout.EAST);
            p.add(Box.createVerticalStrut(5));
            p.add(options);

            styleError(loginError);
            p.add(loginError);
            styleButton(loginButton);
            loginButton.addActionListener(e -> doLogin());
            p.add(loginButton);

            signupRow.setOpaque(false);
            signupRow.setAlignmentX(Component.LEFT_ALIGNMENT);
            signupRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
            signupRow.removeAll();
            JLabel q = new JLabel("Don't have an account?");
            q.setFont(font(Font.PLAIN, 12));
            q.setForeground(new Color(105, 120, 140));
            LinkButton create = new LinkButton("Register here", new Color(42, 103, 174), 12);
            create.addActionListener(e -> {
                signupError.setText(" ");
                forms.show(formCards, "signup");
                heading.setText("Create Account");
                setSub("Register as a resident to request documents and access barangay services.");
                getRootPane().setDefaultButton(signupButton);
            });
            signupRow.add(q);
            signupRow.add(create);
            p.add(Box.createVerticalStrut(15));
            p.add(signupRow);
            return p;
        }
 
        private JComponent buildSignupForm() {
            JPanel p = new JPanel();
            p.setOpaque(false);
            p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
            p.setAlignmentX(Component.LEFT_ALIGNMENT);
            p.setMaximumSize(new Dimension(380, Integer.MAX_VALUE));
            for (JTextField f : new JTextField[]{suName, suContact, suAddress, suUser, suPass, suConfirm}) styleField(f);
            suPurok.setFont(font(Font.PLAIN, 14));
            sized(suPurok);
 
            p.add(label("Full name"));
            p.add(suName);
            JPanel row = new JPanel(new GridLayout(1, 2, 10, 0));
            row.setOpaque(false);
            row.setAlignmentX(Component.LEFT_ALIGNMENT);
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
            JPanel a = new JPanel(); a.setOpaque(false); a.setLayout(new BoxLayout(a, BoxLayout.Y_AXIS));
            JPanel b = new JPanel(); b.setOpaque(false); b.setLayout(new BoxLayout(b, BoxLayout.Y_AXIS));
            a.add(label("Purok")); suPurok.setPreferredSize(new Dimension(150, 38)); a.add(suPurok);
            b.add(label("Mobile number")); suContact.setPreferredSize(new Dimension(150, 38)); b.add(suContact);
            row.add(a); row.add(b);
            p.add(row);
            p.add(label("Address"));
            p.add(suAddress);
            p.add(label("Username"));
            p.add(suUser);
            JPanel row2 = new JPanel(new GridLayout(1, 2, 10, 0));
            row2.setOpaque(false);
            row2.setAlignmentX(Component.LEFT_ALIGNMENT);
            row2.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
            JPanel c = new JPanel(); c.setOpaque(false); c.setLayout(new BoxLayout(c, BoxLayout.Y_AXIS));
            JPanel d = new JPanel(); d.setOpaque(false); d.setLayout(new BoxLayout(d, BoxLayout.Y_AXIS));
            c.add(label("Password")); suPass.setPreferredSize(new Dimension(150, 38)); c.add(suPass);
            d.add(label("Confirm password")); suConfirm.setPreferredSize(new Dimension(150, 38)); d.add(suConfirm);
            row2.add(c); row2.add(d);
            p.add(row2);
 
            styleError(signupError);
            p.add(signupError);
            styleButton(signupButton);
            signupButton.addActionListener(e -> doSignup());
            p.add(signupButton);
 
            JPanel back = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
            back.setOpaque(false);
            back.setAlignmentX(Component.LEFT_ALIGNMENT);
            back.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
            JLabel q = new JLabel("Already have an account?");
            q.setFont(font(Font.PLAIN, 13));
            q.setForeground(TXT_SOFT);
            LinkButton login = new LinkButton("Log in", LINK, 13);
            login.addActionListener(e -> setRole(false));
            back.add(q);
            back.add(login);
            p.add(Box.createVerticalStrut(10));
            p.add(back);
            return p;
        }
 
        private void setRole(boolean admin) {
            adminMode = admin;
            residentTab.setSelectedTab(!admin);
            adminTab.setSelectedTab(admin);
            heading.setText(admin ? "Barangay Staff Log In" : "Resident Sign In");
            setSub(admin
                    ? "Authorized barangay staff only. Use your staff username and password."
                    : "Sign in with your resident account to request documents and view services.");
            loginButton.setText(admin ? "Log In as Staff" : "Sign In as Resident");
            signupRow.setVisible(!admin);
            loginError.setText(" ");
            passField.setText("");
            forms.show(formCards, "login");
            getRootPane().setDefaultButton(loginButton);
            SwingUtilities.invokeLater(userField::requestFocusInWindow);
        }
 
        private void doLogin() {
            long now = System.currentTimeMillis();
            if (now < lockedUntil) {
                loginError.setText("Too many failed attempts. Try again in " + ((lockedUntil - now) / 1000 + 1) + " seconds.");
                return;
            }
            String u = userField.getText().trim();
            String p = new String(passField.getPassword());
            if (u.isEmpty() || p.isEmpty()) {
                loginError.setText("Please enter your username and password.");
                return;
            }
            User user = AuthManager.authenticate(adminMode, u, p);
            if (user == null) {
                failedAttempts++;
                if (failedAttempts >= 5) {
                    failedAttempts = 0;
                    lockedUntil = System.currentTimeMillis() + 30000;
                    loginError.setText("Too many failed attempts. Account locked for 30 seconds.");
                } else {
                    User exists = AuthManager.find(u);
                    if (exists != null && exists.isAdmin() != adminMode) {
                        loginError.setText(adminMode
                                ? "This is a resident account. Switch to the Resident tab to sign in."
                                : "This is a staff account. Switch to the Staff Log In tab to log in.");
                    } else {
                        loginError.setText(adminMode
                                ? "Incorrect staff username or password."
                                : "Incorrect resident username or password.");
                    }
                }
                passField.setText("");
                return;
            }
            failedAttempts = 0;
            new BarangayServicesApplication(user).setVisible(true);
            dispose();
        }
 
        private void doSignup() {
            String err = AuthManager.registerResident(suName.getText(), String.valueOf(suPurok.getSelectedItem()),
                    suContact.getText().trim(), suAddress.getText(), suUser.getText().trim(),
                    new String(suPass.getPassword()), new String(suConfirm.getPassword()));
            if (err != null) {
                signupError.setText(err);
                return;
            }
            String username = suUser.getText().trim();
            for (JTextField f : new JTextField[]{suName, suContact, suAddress, suUser, suPass, suConfirm}) f.setText("");
            JOptionPane.showMessageDialog(this,
                    "Your resident account has been created successfully.\n\n"
                            + "You can now sign in using the Resident tab with username:\n" + username,
                    "Resident Sign Up Successful", JOptionPane.INFORMATION_MESSAGE);
            setRole(false);
            userField.setText(username);
            passField.requestFocusInWindow();
        }
    }
 
    // =====================================================================
    //  Main frame (shown after log in)
    // =====================================================================
    public BarangayServicesApplication(User user) {
        this.currentUser = user;
        String notificationIdentity = (user.role + "_" + user.username).replaceAll("[^A-Za-z0-9_.-]", "_");
        this.notificationReadFile = new File("barangay_read_notifications_" + notificationIdentity + ".txt");
        this.notificationSettingsFile = new File("barangay_notification_settings_" + notificationIdentity + ".txt");
        this.viewedNotificationKeys = loadViewedNotificationKeys(notificationReadFile);
        this.notificationsEnabled = loadNotificationPreference(notificationSettingsFile);
        this.pages = user.isAdmin() ? ADMIN_PAGES : RESIDENT_PAGES;
        // Seed the in-memory baseline so the sound only plays for notifications that arrive
        // during this session; unread items still retain their persisted red badges.
        for (Object[] row : notificationRows()) knownNotificationKeys.add(String.valueOf(row[4]));
        setTitle("Baryo Konek");
        setIconImage(windowIcon());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // A compact minimum size allows the layout to adapt to smaller laptop/tablet
        // windows while the icon-only sidebar keeps every navigation action available.
        setMinimumSize(new Dimension(520, 480));
        setSize(1440, 900);
        setLocationRelativeTo(null);
        setContentPane(new GradientPanel(new BorderLayout(0, 0), G_TOP, G_BOTTOM, true));

        // No top header: both columns begin at y=0 and fill the complete frame height.
        add(createSidebar(), BorderLayout.WEST);

        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setOpaque(false);
        contentPanel.setBorder(new EmptyBorder(0, 24, 20, 24));
        pageCards.setOpaque(false);
        for (String page : pages) pageCards.add(createPage(page), page);
        contentPanel.add(pageCards, BorderLayout.CENTER);
        add(contentPanel, BorderLayout.CENTER);

        addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override public void componentResized(java.awt.event.ComponentEvent e) {
                updateResponsiveLayout();
            }
        });
        updateResponsiveLayout();
        showPage("Home");

        // Poll database changes so request completions and newly posted announcements
        // create visible alerts and a short system notification sound for residents.
        notificationRefreshTimer = new javax.swing.Timer(12000, e -> {
            RequestStore.reload();
            refreshAnnouncementStores();
            List<Object[]> newNotificationRows = new ArrayList<>();
            for (Object[] row : notificationRows()) {
                String key = String.valueOf(row[4]);
                if (knownNotificationKeys.add(key) && !viewedNotificationKeys.contains(key))
                    newNotificationRows.add(row);
            }
            if (!newNotificationRows.isEmpty() && notificationsEnabled) {
                playNotificationSound();
                showNotificationPopup(newNotificationRows);
            }
            if ("Notifications".equals(currentPage)) {
                notificationsWrap.removeAll();
                notificationsWrap.add(createNotificationsPage(), BorderLayout.CENTER);
                notificationsWrap.revalidate();
                notificationsWrap.repaint();
                markNotificationsAsViewed();
            } else if ("Announcements".equals(currentPage)) {
                refreshAnnouncements();
                if (!isAdmin()) markAnnouncementNotificationsAsViewed();
            } else if ("Home".equals(currentPage)) {
                refreshDashboard();
            }
            if ("Document Requests".equals(currentPage)) refreshDocumentRequests();
            if ("History".equals(currentPage)) refreshHistory();
            refreshNotificationBadge();
        });
        notificationRefreshTimer.setInitialDelay(8000);
        notificationRefreshTimer.start();
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override public void windowClosed(java.awt.event.WindowEvent e) {
                if (notificationRefreshTimer != null) notificationRefreshTimer.stop();
            }
        });
    }
 
    private JComponent createSidebar() {
        sidebarPanel = new GradientPanel(new BorderLayout(0, 14),
                new Color(6, 22, 48), new Color(3, 8, 18), true);
        sidebarPanel.setPreferredSize(new Dimension(236, 100));
        sidebarPanel.setMinimumSize(new Dimension(64, 100));
        sidebarPanel.setBorder(new EmptyBorder(18, 14, 16, 14));

        sidebarBrandPanel = new JPanel(new BorderLayout(10, 0));
        sidebarBrandPanel.setOpaque(false);
        sidebarBrandPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 58));
        sidebarLogo = new BarangayPhoto(48, 48, 12, null, null);
        sidebarBrandText = new JPanel();
        sidebarBrandText.setOpaque(false);
        sidebarBrandText.setLayout(new BoxLayout(sidebarBrandText, BoxLayout.Y_AXIS));
        JLabel brand = new JLabel("Baryo Konek");
        brand.setForeground(Color.WHITE);
        brand.setFont(font(Font.BOLD, 17));
        JLabel portal = new JLabel(isAdmin() ? "Admin Portal" : "Resident Portal");
        portal.setForeground(new Color(150, 195, 235));
        portal.setFont(font(Font.PLAIN, 12));
        sidebarBrandText.add(Box.createVerticalGlue());
        sidebarBrandText.add(brand);
        sidebarBrandText.add(Box.createVerticalStrut(3));
        sidebarBrandText.add(portal);
        sidebarBrandText.add(Box.createVerticalGlue());
        sidebarBrandPanel.add(sidebarLogo, BorderLayout.WEST);
        sidebarBrandPanel.add(sidebarBrandText, BorderLayout.CENTER);
        sidebarPanel.add(sidebarBrandPanel, BorderLayout.NORTH);

        sidebarNavList = new JPanel();
        sidebarNavList.setOpaque(false);
        sidebarNavList.setLayout(new BoxLayout(sidebarNavList, BoxLayout.Y_AXIS));
        for (String page : pages) {
            NavButton button = new NavButton(page, glyphFor(page));
            if ("Notifications".equals(page)) button.setBadgeCount(unreadNotificationCount());
            button.addActionListener(e -> showPage(page));
            navButtons.add(button);
            sidebarNavList.add(button);
            sidebarNavList.add(Box.createVerticalStrut(6));
        }
        JScrollPane navScroll = new JScrollPane(sidebarNavList,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        navScroll.setBorder(null);
        navScroll.setOpaque(false);
        navScroll.getViewport().setOpaque(false);
        navScroll.getVerticalScrollBar().setUnitIncrement(18);
        sidebarPanel.add(navScroll, BorderLayout.CENTER);

        sidebarUserCard = new RoundPanel(new BorderLayout(4, 0), 16,
                new Color(255, 255, 255, 30), null, false);
        sidebarUserCard.setBorder(new EmptyBorder(10, 12, 12, 8));
        sidebarUserLabel = new JLabel("", new VectorIcon(Glyph.PEOPLE, 28, Color.WHITE), SwingConstants.LEFT);
        sidebarUserLabel.setIconTextGap(8);
        sidebarUserLabel.setForeground(Color.WHITE);
        sidebarUserLabel.setFont(font(Font.PLAIN, 13));
        sidebarUserCard.add(sidebarUserLabel, BorderLayout.CENTER);
        sidebarLogoutButton = new LinkButton("Log out", new Color(255, 214, 140), 12);
        sidebarLogoutButton.addActionListener(e -> logOut());
        sidebarUserCard.add(sidebarLogoutButton, BorderLayout.EAST);
        sidebarPanel.add(sidebarUserCard, BorderLayout.SOUTH);

        updateResponsiveLayout();
        return sidebarPanel;
    }

    /**
     * Responsive shell sizing:
     * - wide desktop: full sidebar with labels;
     * - medium desktop/tablet: full-label sidebar with reduced content margins;
     * - narrow/mobile-sized window: icon rail with tooltips and a compact logout control.
     * The content always starts at the top edge and retains the current color/style system.
     */
    private void updateResponsiveLayout() {
        if (sidebarPanel == null || contentPanel == null) return;
        int width = Math.max(getWidth(), 520);
        int mode = width < 760 ? 0 : (width < 1080 ? 1 : 2);
        if (mode == responsiveMode) return;
        responsiveMode = mode;

        boolean compact = mode == 0;
        int sidebarWidth = compact ? 68 : 236;
        int horizontalInset = compact ? 7 : 14;
        sidebarPanel.setPreferredSize(new Dimension(sidebarWidth, Math.max(100, getHeight())));
        sidebarPanel.setBorder(new EmptyBorder(compact ? 12 : 18, horizontalInset,
                14, horizontalInset));

        sidebarBrandPanel.removeAll();
        if (compact) {
            sidebarBrandPanel.setPreferredSize(new Dimension(sidebarWidth - horizontalInset * 2, 48));
            sidebarBrandPanel.add(sidebarLogo, BorderLayout.CENTER);
            sidebarBrandText.setVisible(false);
        } else {
            sidebarBrandPanel.setPreferredSize(new Dimension(sidebarWidth - horizontalInset * 2, 58));
            sidebarBrandText.setVisible(true);
            sidebarBrandPanel.add(sidebarLogo, BorderLayout.WEST);
            sidebarBrandPanel.add(sidebarBrandText, BorderLayout.CENTER);
        }
        for (NavButton button : navButtons) button.setCompact(compact);
        Dimension navPreferred = sidebarNavList.getPreferredSize();
        sidebarNavList.setPreferredSize(new Dimension(
                Math.max(1, sidebarWidth - horizontalInset * 2), navPreferred.height));

        String shown = isAdmin() ? "Admin" : currentUser.firstName();
        if (compact) {
            sidebarUserCard.removeAll();
            sidebarUserCard.setLayout(new BoxLayout(sidebarUserCard, BoxLayout.Y_AXIS));
            sidebarUserCard.setBorder(new EmptyBorder(7, 3, 7, 3));
            sidebarUserLabel.setText("");
            sidebarUserLabel.setHorizontalAlignment(SwingConstants.CENTER);
            sidebarUserLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebarLogoutButton.setText("↪");
            sidebarLogoutButton.setFont(font(Font.BOLD, 18));
            sidebarLogoutButton.setToolTipText("Log out");
            sidebarLogoutButton.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebarUserCard.add(sidebarUserLabel);
            sidebarUserCard.add(Box.createVerticalStrut(3));
            sidebarUserCard.add(sidebarLogoutButton);
            sidebarUserCard.setPreferredSize(new Dimension(sidebarWidth - horizontalInset * 2, 76));
        } else {
            sidebarUserCard.removeAll();
            sidebarUserCard.setLayout(new BorderLayout(4, 0));
            sidebarUserCard.setBorder(new EmptyBorder(10, 12, 12, 8));
            sidebarUserLabel.setText("<html><b>" + esc(shown) + "</b><br><span style='font-size:10px'>"
                    + (isAdmin() ? "Barangay Staff" : "Resident") + "</span></html>");
            sidebarUserLabel.setHorizontalAlignment(SwingConstants.LEFT);
            sidebarLogoutButton.setText("Log out");
            sidebarLogoutButton.setFont(font(Font.PLAIN, 12));
            sidebarLogoutButton.setToolTipText("Log out");
            sidebarUserCard.add(sidebarUserLabel, BorderLayout.CENTER);
            sidebarUserCard.add(sidebarLogoutButton, BorderLayout.EAST);
            sidebarUserCard.setPreferredSize(new Dimension(sidebarWidth - horizontalInset * 2, 62));
        }
        contentPanel.setBorder(new EmptyBorder(0, compact ? 10 : (mode == 1 ? 16 : 24),
                compact ? 12 : 20, compact ? 10 : (mode == 1 ? 16 : 24)));
        sidebarPanel.revalidate();
        sidebarPanel.repaint();
        contentPanel.revalidate();
        contentPanel.repaint();
        revalidate();
    }

    private void logOut() {
        int ok = JOptionPane.showConfirmDialog(this, "Log out of your account?", "Log Out",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (ok != JOptionPane.YES_OPTION) return;
        new LoginFrame().setVisible(true);
        dispose();
    }

    /** Switches between light and dark mode, keeping the same page, size and position. */
    private void toggleTheme() {
        applyTheme(!darkMode);
        BarangayServicesApplication f = new BarangayServicesApplication(currentUser);
        f.showPage(currentPage);
        f.setBounds(getBounds());
        f.setExtendedState(getExtendedState());
        f.setVisible(true);
        dispose();
    }
 
    /** Rebuilds the dashboard so it shows the latest saved data. */
    private void refreshDashboard() {
        dashboardWrap.removeAll();
        dashboardWrap.add(createDashboard(), BorderLayout.CENTER);
        dashboardWrap.revalidate();
        dashboardWrap.repaint();
    }

    /** Parse the date formats used by the announcement form and older saved records. */
    private static LocalDate parseAnnouncementDate(String value) {
        if (value == null || value.isBlank()) return null;
        String[] patterns = {"MMM d, yyyy", "MMMM d, yyyy", "M/d/yyyy", "MM/dd/yyyy", "yyyy-MM-dd", "d MMM yyyy"};
        for (String pattern : patterns) {
            try { return LocalDate.parse(value.trim(), DateTimeFormatter.ofPattern(pattern, Locale.ENGLISH)); }
            catch (Exception ignored) { }
        }
        return null;
    }

    /**
     * A single view of every saved announcement category. Health and Education
     * records are intentionally retained in PostgreSQL and displayed here, rather
     * than requiring separate sidebar pages. Each row is:
     * category, title, date, location, status, source key, source index.
     */
    private static List<Object[]> allAnnouncementRecords() {
        List<Object[]> records = new ArrayList<>();
        String[][] sources = {{"announcements", "Barangay"}, {"health", "Health"}, {"education", "Education"}};
        for (String[] source : sources) {
            String key = source[0];
            List<Object[]> storedRows = ListStore.get(key);
            int[] pos = annPositions(key);
            for (int i = 0; i < storedRows.size(); i++) {
                Object[] stored = storedRows.get(i);
                records.add(new Object[]{source[1], cell(stored, pos[0]), cell(stored, pos[1]),
                        announcementLocation(key, stored), cell(stored, pos[2]), key, String.valueOf(i)});
            }
        }
        // A stable, global newest-first ordering ensures no category's records are hidden
        // behind another category and every saved item appears in the unified list.
        records.sort((left, right) -> {
            LocalDate dl = parseAnnouncementDate(String.valueOf(left[2]));
            LocalDate dr = parseAnnouncementDate(String.valueOf(right[2]));
            if (dl != null && dr != null) return dr.compareTo(dl);
            if (dl != null) return -1;
            if (dr != null) return 1;
            return String.valueOf(right[2]).compareToIgnoreCase(String.valueOf(left[2]));
        });
        return records;
    }

    /** Compact announcement preview for the Home page. */
    private static Object[][] dashboardAnnouncements() {
        List<Object[]> out = new ArrayList<>();
        for (Object[] row : allAnnouncementRecords())
            out.add(new Object[]{row[0], row[1], row[2], row[4]});
        return out.toArray(new Object[0][]);
    }

    /** Full resident-facing list including date, location and status. */
    private static Object[][] residentAnnouncementRows() {
        List<Object[]> out = new ArrayList<>();
        for (Object[] row : allAnnouncementRecords())
            out.add(new Object[]{row[0], row[1], row[2], row[3], row[4]});
        return out.toArray(new Object[0][]);
    }

    private static String storeKey(String title) {
        switch (title) {
            case "Barangay Announcements": return "announcements";
            case "Barangay Documents Catalog": return "documents";
            default: return null;
        }
    }

    private void showPage(String page) {
        currentPage = page;
        if ("Notifications".equals(page)) {
            RequestStore.reload();
            refreshAnnouncementStores();
            notificationsWrap.removeAll();
            notificationsWrap.add(createNotificationsPage(), BorderLayout.CENTER);
            notificationsWrap.revalidate();
            notificationsWrap.repaint();
            markNotificationsAsViewed();
        }
        cardLayout.show(pageCards, page);
        if ("Home".equals(page)) {
            refreshAnnouncementStores();
            refreshDashboard();
        }
        if ("Document Requests".equals(page)) refreshDocumentRequests();
        if ("History".equals(page)) refreshHistory();
        if ("Announcements".equals(page)) {
            refreshAnnouncementStores();
            refreshAnnouncements();
            markAnnouncementNotificationsAsViewed();
        }
        refreshNotificationBadge();
        setTitle("Baryo Konek — " + page);
        for (NavButton b : navButtons) b.setSelectedPage(b.getText().equals(page));
    }
 
    private JPanel createPage(String page) {
        JPanel panel = new JPanel(new BorderLayout(0, 16));
        panel.setOpaque(false);
        JLabel heading = new JLabel(page, new VectorIcon(glyphFor(page), 30, LINK), SwingConstants.LEFT);
        heading.setIconTextGap(12);
        heading.setFont(font(Font.BOLD, 26));
        heading.setForeground(TXT);
        if (!"Home".equals(page)) panel.add(heading, BorderLayout.NORTH);
 
        switch (page) {
            case "Home":
                dashboardWrap.setOpaque(false);
                dashboardWrap.add(createDashboard(), BorderLayout.CENTER);
                panel.add(dashboardWrap, BorderLayout.CENTER);
                break;
            case "Announcements":
                announcementsWrap.setOpaque(false);
                announcementsWrap.add(createAnnouncementsPage(), BorderLayout.CENTER);
                panel.add(announcementsWrap, BorderLayout.CENTER);
                break;
            case "Barangay Documents": panel.add(createBarangayDocumentsPage(), BorderLayout.CENTER); break;
            case "Document Requests":
                requestsWrap.setOpaque(false);
                requestsWrap.add(createDocumentsPage(), BorderLayout.CENTER);
                panel.add(requestsWrap, BorderLayout.CENTER);
                break;
            case "History":
                historyWrap.setOpaque(false);
                historyWrap.add(createHistoryPage(), BorderLayout.CENTER);
                panel.add(historyWrap, BorderLayout.CENTER);
                break;
            case "Residents": panel.add(createResidentsPage(), BorderLayout.CENTER); break;
            case "My Profile": panel.add(createSettingsPage(), BorderLayout.CENTER); break;
            case "Settings": panel.add(createSettingsPage(), BorderLayout.CENTER); break;
            case "Notifications":
                notificationsWrap.setOpaque(false);
                notificationsWrap.add(createNotificationsPage(), BorderLayout.CENTER);
                panel.add(notificationsWrap, BorderLayout.CENTER);
                break;
            default: panel.add(createDashboard(), BorderLayout.CENTER);
        }
        return panel;
    }
 
    // =====================================================================
    //  Pages
    // =====================================================================
    private JComponent createDashboard() {
        JPanel root = new JPanel(new BorderLayout(0, 18));
        root.setOpaque(false);
        // Keep a modest breathing space above the dashboard banner without
        // restoring the removed application header or shifting other pages.
        root.setBorder(new EmptyBorder(14, 0, 0, 0));
 
        // ---- top: hero photo + stat cards
        JPanel top = new JPanel(new BorderLayout(0, 16));
        top.setOpaque(false);
        String welcome = isAdmin() ? "Welcome to Barangay Indangan!"
                : "Welcome to Barangay Indangan, " + currentUser.firstName() + "!";
        BarangayPhoto hero = new BarangayPhoto(100, 176, 26, welcome,
                "Fast, organized and accessible services for every resident.");
        hero.focus(0.55f);
        top.add(hero, BorderLayout.NORTH);
 
        int pending = RequestStore.pendingFor(currentUser);
        int activeAnnouncements = ListStore.count("announcements", 2, "Active")
                + ListStore.count("health", 4, "Active") + ListStore.count("education", 4, "Active");
        JPanel stats = new JPanel(new GridLayout(1, 3, 16, 0));
        stats.setOpaque(false);
        if (isAdmin()) {
            stats.add(statCard(Glyph.PEOPLE, String.valueOf(AuthManager.residents().size()), "Registered Residents", BLUE, "Residents"));
            stats.add(statCard(Glyph.REQUEST, String.valueOf(pending), "Pending Requests", new Color(232, 140, 0), "Document Requests"));
        } else {
            stats.add(statCard(Glyph.REQUEST, String.valueOf(pending), "My Pending Requests", new Color(232, 140, 0), "Document Requests"));
            stats.add(statCard(Glyph.DOC, String.valueOf(ListStore.count("documents", 3, "Available")),
                    "Available Documents", BLUE, "Barangay Documents"));
        }
        stats.add(statCard(Glyph.MEGAPHONE, String.valueOf(activeAnnouncements), "Active Announcements", new Color(124, 77, 255), "Announcements"));
        top.add(stats, BorderLayout.SOUTH);
        root.add(top, BorderLayout.NORTH);
 
        // ---- bottom: recent announcements (2/3) + scrollable quick actions (1/3)
        JPanel lower = new JPanel(new GridBagLayout());
        lower.setOpaque(false);
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.BOTH;
        gc.weighty = 1;
        gc.gridx = 0; gc.weightx = 2; gc.insets = new Insets(0, 0, 0, 16);
        String[] cols = {"Category", "Announcement", "Date", "Status"};
        Object[][] rows = dashboardAnnouncements();
        lower.add(tableCard("Recent Announcements", cols, rows, null), gc);
        gc.gridx = 1; gc.weightx = 1; gc.insets = new Insets(0, 0, 0, 0);
        lower.add(quickActions(), gc);
        root.add(lower, BorderLayout.CENTER);
        return root;
    }
 
    /** Stat card. Its text is written in HTML + CSS (Swing supports inline CSS in labels). */
    private JPanel statCard(Glyph glyph, String number, String label, Color accent, String target) {
        RoundPanel card = new RoundPanel(new BorderLayout(14, 0), 20, CARD, CARD_BORDER, true);
        card.setBorder(new EmptyBorder(16, 18, 18, 18));
        JPanel badgeWrap = new JPanel(new GridBagLayout());
        badgeWrap.setOpaque(false);
        badgeWrap.add(new IconBadge(glyph, accent));
        card.add(badgeWrap, BorderLayout.WEST);
 
        JLabel text = new JLabel("<html><div style='font-family:Segoe UI, SansSerif;'>"
                + "<span style='font-size:26px; font-weight:bold; color:" + HEX_TXT + ";'>" + number + "</span><br>"
                + "<span style='font-size:12px; color:" + HEX_SOFT + ";'>" + label + "</span>"
                + "</div></html>");
        card.add(text, BorderLayout.CENTER);
 
        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        card.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) { showPage(target); }
        });
        return card;
    }
 
    private JPanel quickActions() {
        RoundPanel card = new RoundPanel(new BorderLayout(0, 12), 20, CARD, CARD_BORDER, true);
        card.setBorder(new EmptyBorder(18, 20, 20, 20));

        JPanel intro = new JPanel();
        intro.setOpaque(false);
        intro.setLayout(new BoxLayout(intro, BoxLayout.Y_AXIS));
        JLabel heading = new JLabel("Quick Actions");
        heading.setFont(font(Font.BOLD, 18));
        heading.setForeground(TXT);
        heading.setAlignmentX(Component.LEFT_ALIGNMENT);
        intro.add(heading);
        intro.add(Box.createVerticalStrut(6));
        JLabel hint = new JLabel("<html><div style='font-family:Segoe UI, SansSerif; font-size:12px; color:" + HEX_SOFT + "; width:230px;'>"
                + (isAdmin() ? "Jump straight to the most common tasks of barangay staff."
                : "Jump straight to the services you use most.") + "</div></html>");
        hint.setAlignmentX(Component.LEFT_ALIGNMENT);
        intro.add(hint);
        card.add(intro, BorderLayout.NORTH);

        String[][] actions = isAdmin() ? new String[][]{
                {"Document Requests", "Document Requests"},
                {"Completed Request History", "History"},
                {"Registered Residents", "Residents"},
                {"Post Announcement", "Announcements"},
                {"View Notifications", "Notifications"},
                {"Account Settings", "Settings"}
        } : new String[][]{
                {"Request a Document", "Document Requests"},
                {"View Barangay Documents", "Barangay Documents"},
                {"View Request History", "History"},
                {"View Announcements", "Announcements"},
                {"View Notifications", "Notifications"},
                {"Account Settings", "Settings"}
        };
        JPanel actionList = new JPanel();
        actionList.setOpaque(false);
        actionList.setLayout(new BoxLayout(actionList, BoxLayout.Y_AXIS));
        for (String[] a : actions) {
            PillButton b = new PillButton(a[0]);
            b.setAlignmentX(Component.LEFT_ALIGNMENT);
            b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            b.addActionListener(e -> showPage(a[1]));
            actionList.add(b);
            actionList.add(Box.createVerticalStrut(10));
        }
        JScrollPane actionScroll = new JScrollPane(actionList,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        actionScroll.setBorder(BorderFactory.createEmptyBorder());
        actionScroll.setOpaque(false);
        actionScroll.getViewport().setOpaque(false);
        actionScroll.getVerticalScrollBar().setUnitIncrement(18);
        actionScroll.setPreferredSize(new Dimension(270, 300));
        card.add(actionScroll, BorderLayout.CENTER);
        return card;
    }

    /** Announcements page: shows Barangay + Health + Education announcements (same as the dashboard). */
    private JComponent createAnnouncementsPage() {
        annSources.clear();
        if (!isAdmin()) {
            // Residents: read-only
            String[] residentCols = {"Category", "Announcement", "Date", "Location", "Status"};
            return tableCard("All Announcements", residentCols, residentAnnouncementRows(), null);
        }
        // Admin: everything in one table, each row can be edited / deleted
        String[] cols = {"Category", "Title", "Date", "Location", "Status", "Actions"};
        Object[][] rows = combinedAnnouncements();
        return tableCard("All Announcements", cols, rows, "+ New Announcement");
    }

    /** Rebuilds the Announcements page so it shows the latest saved data. */
    private void refreshAnnouncements() {
        announcementsWrap.removeAll();
        announcementsWrap.add(createAnnouncementsPage(), BorderLayout.CENTER);
        announcementsWrap.revalidate();
        announcementsWrap.repaint();
    }

    private static Object cell(Object[] r, int i) { return i < r.length ? r[i] : ""; }

    /** Position of {title, date, status} inside a saved row of the given list. */
    private static int[] annPositions(String key) {
        return "announcements".equals(key) ? new int[]{0, 1, 2} : new int[]{0, 2, 4};
    }

    private static String announcementLocation(String key, Object[] row) {
        if (row == null) return "";
        if ("announcements".equals(key)) return row.length > 4 ? String.valueOf(row[4]) : "";
        return row.length > 3 ? String.valueOf(row[3]) : "";
    }

    private static String announcementId(Object[] row) {
        if (row != null && row.length > 0) {
            String candidate = String.valueOf(row[row.length - 1]);
            if (candidate.matches("[0-9a-fA-F-]{36}")) return candidate;
        }
        return "legacy-" + String.valueOf(row == null ? "" : row[0]) + "-" + String.valueOf(row == null || row.length < 3 ? "" : row[row.length > 4 ? 2 : 1]);
    }

    /** Admin sees every announcement category in one newest-first table. */
    private Object[][] combinedAnnouncements() {
        annSources.clear();
        List<Object[]> out = new ArrayList<>();
        for (Object[] record : allAnnouncementRecords()) {
            out.add(new Object[]{record[0], record[1], record[2], record[3], record[4], "Edit / Delete"});
            annSources.add(new String[]{String.valueOf(record[5]), String.valueOf(record[6])});
        }
        return out.toArray(new Object[0][]);
    }

    private void addCombinedAnnouncement() {
        JComboBox<String> category = new JComboBox<>(new String[]{"Barangay", "Health", "Education"});
        JTextField title = new JTextField(20);
        String today = LocalDate.now().format(DateTimeFormatter.ofPattern("MMM dd, yyyy", Locale.ENGLISH));
        JTextField date = new JTextField(today, 20);
        JTextField location = new JTextField(20);
        JComboBox<String> status = new JComboBox<>(new String[]{"Active", "Inactive"});
        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.add(new JLabel("Category:")); form.add(category);
        form.add(new JLabel("Title:")); form.add(title);
        form.add(new JLabel("Date:")); form.add(date);
        form.add(new JLabel("Location:")); form.add(location);
        form.add(new JLabel("Status:")); form.add(status);
        int result = JOptionPane.showConfirmDialog(this, form, "New Announcement",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;
        if (title.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in the Title.", "Missing Information",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        String cat = String.valueOf(category.getSelectedItem());
        String st = String.valueOf(status.getSelectedItem());
        String announcementId = java.util.UUID.randomUUID().toString();
        if ("Barangay".equals(cat))
            ListStore.add("announcements", new Object[]{title.getText().trim(), date.getText().trim(), st, "Edit / Delete", location.getText().trim(), announcementId});
        else
            ListStore.add("Health".equals(cat) ? "health" : "education",
                    new Object[]{title.getText().trim(), "General", date.getText().trim(), location.getText().trim(), st, "Edit / Delete", announcementId});
        refreshAnnouncementStores();
        refreshAnnouncements();
        refreshDashboard();
        refreshNotificationBadge();
    }

    private void editCombinedAnnouncement(int m) {
        if (m < 0 || m >= annSources.size()) return;
        String key = annSources.get(m)[0];
        int idx = Integer.parseInt(annSources.get(m)[1]);
        List<Object[]> list = ListStore.get(key);
        if (idx >= list.size()) return;
        Object[] stored = list.get(idx).clone();
        int[] pos = annPositions(key);
        JTextField title = new JTextField(String.valueOf(cell(stored, pos[0])), 20);
        JTextField date = new JTextField(String.valueOf(cell(stored, pos[1])), 20);
        JTextField location = new JTextField(announcementLocation(key, stored), 20);
        JComboBox<String> status = new JComboBox<>(new String[]{"Active", "Inactive"});
        status.setSelectedItem(String.valueOf(cell(stored, pos[2])));
        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.add(new JLabel("Title:")); form.add(title);
        form.add(new JLabel("Date:")); form.add(date);
        form.add(new JLabel("Location:")); form.add(location);
        form.add(new JLabel("Status:")); form.add(status);
        int result = JOptionPane.showConfirmDialog(this, form, "Edit Announcement",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;
        if (title.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in the Title.", "Missing Information",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Save the changes to this item?",
                "Confirm Edit", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;
        stored[pos[0]] = title.getText().trim();
        stored[pos[1]] = date.getText().trim();
        stored[pos[2]] = String.valueOf(status.getSelectedItem());
        if ("announcements".equals(key)) {
            if (stored.length < 6) stored = Arrays.copyOf(stored, 6);
            stored[4] = location.getText().trim();
            if (stored[5] == null || String.valueOf(stored[5]).isBlank()) stored[5] = java.util.UUID.randomUUID().toString();
        } else {
            if (stored.length < 7) stored = Arrays.copyOf(stored, 7);
            stored[3] = location.getText().trim();
            if (stored[6] == null || String.valueOf(stored[6]).isBlank()) stored[6] = java.util.UUID.randomUUID().toString();
        }
        ListStore.set(key, idx, stored);
        refreshAnnouncementStores();
        refreshAnnouncements();
        refreshDashboard();
        refreshNotificationBadge();
    }

    private void deleteCombinedAnnouncement(int m) {
        if (m < 0 || m >= annSources.size()) return;
        String key = annSources.get(m)[0];
        int idx = Integer.parseInt(annSources.get(m)[1]);
        List<Object[]> list = ListStore.get(key);
        if (idx >= list.size()) return;
        String name = String.valueOf(cell(list.get(idx), 0));
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete \"" + name + "\"?\nThis cannot be undone.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;
        ListStore.remove(key, idx);
        refreshAnnouncementStores();
        refreshAnnouncements();
        refreshDashboard();
        refreshNotificationBadge();
    }

    /** Returns only catalog entries that staff currently mark as Available. */
    private static List<String> availableDocumentTypes() {
        List<String> available = new ArrayList<>();
        for (Object[] row : ListStore.refresh("documents")) {
            if (row == null || row.length < 4) continue;
            String name = String.valueOf(row[0]).trim();
            String availability = String.valueOf(row[3]).trim();
            if (!name.isEmpty() && "Available".equalsIgnoreCase(availability) && !available.contains(name)) {
                available.add(name);
            }
        }
        return available;
    }

    private static boolean isDocumentCurrentlyAvailable(String documentName) {
        if (documentName == null) return false;
        for (String name : availableDocumentTypes()) {
            if (name.equalsIgnoreCase(documentName.trim())) return true;
        }
        return false;
    }

    private JComponent createBarangayDocumentsPage() {
        // The catalog is stored in PostgreSQL through ListStore, so additions and
        // availability changes remain visible to residents after the app restarts.
        String[] cols = {"Document Name", "Description", "Requirements", "Availability", "Actions"};
        Object[][] rows = ListStore.rows("documents");
        JPanel page = new JPanel(new BorderLayout(0, 14));
        page.setOpaque(false);
        JLabel info = new JLabel(isAdmin()
                ? "Add barangay documents and update whether each document is currently available."
                : "View barangay documents, requirements, and current availability. Please contact barangay staff for questions.");
        info.setFont(font(Font.PLAIN, 14));
        info.setForeground(TXT_SOFT);
        page.add(info, BorderLayout.NORTH);
        page.add(tableCard("Barangay Documents Catalog", cols, rows,
                isAdmin() ? "+ Add Document" : null), BorderLayout.CENTER);
        PillButton requestButton = new PillButton(isAdmin() ? "View Document Requests" : "+ Request a Document");
        requestButton.addActionListener(e -> showPage("Document Requests"));
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        bottom.setOpaque(false);
        bottom.add(requestButton);
        page.add(bottom, BorderLayout.SOUTH);
        return page;
    }
 
    private JComponent createDocumentsPage() {
        String[] cols = {"Request ID", "Document Type", "Resident Name", "Purpose", "Date Requested", "Quantity", "Status", "Actions"};
        Object[][] rows = requestTableRows(RequestStore.activeFor(currentUser), true, isAdmin());
        return tableCard(isAdmin() ? "Active Barangay Document Requests" : "My Active Document Requests", cols, rows,
                isAdmin() ? null : "+ New Request");
    }

    private JComponent createHistoryPage() {
        String[] cols = {"Request ID", "Document Type", "Resident Name", "Purpose", "Date Requested", "Quantity", "Status"};
        Object[][] rows = requestTableRows(RequestStore.historyFor(currentUser), false, isAdmin());
        return tableCard(isAdmin() ? "Completed Document Request History" : "My Completed Request History", cols, rows, null);
    }

    private static Object[][] requestTableRows(List<Object[]> requests, boolean includeActions, boolean admin) {
        List<Object[]> rows = new ArrayList<>();
        for (Object[] r : requests) {
            int quantity = r.length > 6 ? Math.max(1, Integer.parseInt(String.valueOf(r[6]))) : 1;
            String status = String.valueOf(r[5]);
            String action = admin
                    ? ("For Acceptance".equalsIgnoreCase(status) ? "Accept"
                        : ("Pending".equalsIgnoreCase(status) ? "Complete" : ""))
                    : ("For Acceptance".equalsIgnoreCase(status) ? "Edit" : "");
            if (includeActions)
                rows.add(new Object[]{r[0], r[1], r[2], r[3], r[4], quantity, status, action});
            else
                rows.add(new Object[]{r[0], r[1], r[2], r[3], r[4], quantity, status});
        }
        return rows.toArray(new Object[0][]);
    }

    private void refreshDocumentRequests() {
        requestsWrap.removeAll();
        requestsWrap.add(createDocumentsPage(), BorderLayout.CENTER);
        requestsWrap.revalidate();
        requestsWrap.repaint();
    }

    private void refreshHistory() {
        historyWrap.removeAll();
        historyWrap.add(createHistoryPage(), BorderLayout.CENTER);
        historyWrap.revalidate();
        historyWrap.repaint();
    }
 
    /** Kinukuha ang numero ng Purok para tama ang pagkakasunod (Purok 2 bago Purok 10). */
    private static int purokNo(String purok) {
        try {
            return Integer.parseInt(purok.replaceAll("\\D", ""));
        } catch (Exception e) {
            return Integer.MAX_VALUE;   // walang Purok = nasa dulo
        }
    }

    private JComponent createResidentsPage() {
        String[] cols = {"Resident ID", "Full Name", "Purok", "Contact Number", "Username", "Status", "Actions"};

        // Pagsunud-sunurin: Purok muna, tapos alphabetical ang pangalan sa loob ng Purok
        List<User> sorted = new ArrayList<>(AuthManager.residents());
        sorted.sort((a, b) -> {
            int c = Integer.compare(purokNo(a.purok), purokNo(b.purok));
            return c != 0 ? c : a.fullName.compareToIgnoreCase(b.fullName);
        });

        List<Object[]> rows = new ArrayList<>();
        int n = 1;
        for (User u : sorted)
            rows.add(new Object[]{String.format("R-%03d", n++), u.fullName, u.purok, u.contact, u.username, "Active", "Delete"});
        return tableCard("Residents Directory", cols, rows.toArray(new Object[0][]), null);
    }
 
    private JComponent createAppearanceCard() {
        RoundPanel appearance = new RoundPanel(new BorderLayout(20, 0), 16, CARD, CARD_BORDER, true);
        appearance.setBorder(new EmptyBorder(18, 22, 18, 22));
        appearance.setMinimumSize(new Dimension(260, 86));
        JPanel labels = new JPanel(new GridLayout(0, 1, 0, 5));
        labels.setOpaque(false);
        JLabel title = new JLabel("Appearance");
        title.setFont(font(Font.BOLD, 16));
        title.setForeground(TXT);
        JLabel note = new JLabel("Choose the color theme used throughout Baryo Konek.");
        note.setFont(font(Font.PLAIN, 13));
        note.setForeground(TXT_SOFT);
        labels.add(title);
        labels.add(note);

        SettingsButton theme = new SettingsButton(darkMode ? "Switch to Light Mode" : "Switch to Dark Mode", true);
        theme.addActionListener(e -> toggleTheme());
        JPanel action = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        action.setOpaque(false);
        action.add(theme);
        appearance.add(labels, BorderLayout.CENTER);
        appearance.add(action, BorderLayout.EAST);
        appearance.setAlignmentX(Component.LEFT_ALIGNMENT);
        return appearance;
    }

    /** Per-account switch for popup alerts, sounds, and unread navigation badges. */
    private JComponent createNotificationSettingsCard() {
        RoundPanel card = new RoundPanel(new BorderLayout(20, 0), 16, CARD, CARD_BORDER, true);
        card.setBorder(new EmptyBorder(18, 22, 18, 22));
        card.setMinimumSize(new Dimension(260, 86));

        JPanel labels = new JPanel(new GridLayout(0, 1, 0, 5));
        labels.setOpaque(false);
        JLabel title = new JLabel("Notifications");
        title.setFont(font(Font.BOLD, 16));
        title.setForeground(TXT);
        JLabel note = new JLabel("Control notification popups, sounds, and unread badges for this account.");
        note.setFont(font(Font.PLAIN, 13));
        note.setForeground(TXT_SOFT);
        labels.add(title);
        labels.add(note);

        SettingsSwitch enabled = new SettingsSwitch(notificationsEnabled);
        JLabel state = new JLabel(notificationsEnabled ? "On" : "Off");
        state.setFont(font(Font.BOLD, 13));
        state.setForeground(notificationsEnabled ? (darkMode ? new Color(112, 220, 166) : new Color(20, 135, 83)) : TXT_SOFT);
        JPanel action = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        action.setOpaque(false);
        action.add(state);
        action.add(enabled);
        enabled.addActionListener(e -> {
            notificationsEnabled = enabled.isSelected();
            state.setText(notificationsEnabled ? "On" : "Off");
            state.setForeground(notificationsEnabled ? (darkMode ? new Color(112, 220, 166) : new Color(20, 135, 83)) : TXT_SOFT);
            try {
                Files.write(notificationSettingsFile.toPath(),
                        (notificationsEnabled ? "on" : "off").getBytes(StandardCharsets.UTF_8));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        "The notification preference could not be saved: " + ex.getMessage(),
                        "Notification Settings", JOptionPane.WARNING_MESSAGE);
            }
            if (!notificationsEnabled && notificationPopup != null && notificationPopup.isShowing())
                notificationPopup.dispose();
            refreshNotificationBadge();
        });

        card.add(labels, BorderLayout.CENTER);
        card.add(action, BorderLayout.EAST);
        card.setAlignmentX(Component.LEFT_ALIGNMENT);
        return card;
    }

    private JPanel createSettingsExtras() {
        JPanel extras = new JPanel();
        extras.setOpaque(false);
        extras.setLayout(new BoxLayout(extras, BoxLayout.Y_AXIS));
        JComponent notificationCard = createNotificationSettingsCard();
        JComponent appearanceCard = createAppearanceCard();
        notificationCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        appearanceCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        extras.add(notificationCard);
        extras.add(Box.createVerticalStrut(12));
        extras.add(appearanceCard);
        return extras;
    }

    /** Residents can update their profile; admins can only change their password here. */
    private JComponent createSettingsPage() {
        JPanel wrapper = new JPanel(new BorderLayout(0, 16));
        wrapper.setOpaque(false);

        if (isAdmin()) {
            JLabel note = new JLabel("Manage your administrator account security and application preferences.");
            note.setFont(font(Font.PLAIN, 14));
            note.setForeground(TXT_SOFT);
            wrapper.add(note, BorderLayout.NORTH);

            RoundPanel securityCard = new RoundPanel(new BorderLayout(20, 0), 16, CARD, CARD_BORDER, true);
            securityCard.setBorder(new EmptyBorder(18, 22, 18, 22));
            securityCard.setMinimumSize(new Dimension(260, 86));
            JPanel text = new JPanel(new GridLayout(0, 1, 0, 5));
            text.setOpaque(false);
            JLabel heading = new JLabel("Password & Security");
            heading.setFont(font(Font.BOLD, 16));
            heading.setForeground(TXT);
            JLabel description = new JLabel("Change the password used to sign in to the admin portal.");
            description.setFont(font(Font.PLAIN, 13));
            description.setForeground(TXT_SOFT);
            text.add(heading);
            text.add(description);
            SettingsButton changePassword = new SettingsButton("Change Password", true);
            changePassword.addActionListener(e -> changePasswordDialog());
            JPanel action = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
            action.setOpaque(false);
            action.add(changePassword);
            securityCard.add(text, BorderLayout.CENTER);
            securityCard.add(action, BorderLayout.EAST);

            JPanel adminSettings = new JPanel();
            adminSettings.setOpaque(false);
            adminSettings.setLayout(new BoxLayout(adminSettings, BoxLayout.Y_AXIS));
            securityCard.setAlignmentX(Component.LEFT_ALIGNMENT);
            JComponent extras = createSettingsExtras();
            extras.setAlignmentX(Component.LEFT_ALIGNMENT);
            adminSettings.add(securityCard);
            adminSettings.add(Box.createVerticalStrut(12));
            adminSettings.add(extras);
            wrapper.add(adminSettings, BorderLayout.CENTER);
            return wrapper;
        }

        JLabel note = new JLabel("Update your personal information and manage your account preferences.");
        note.setFont(font(Font.PLAIN, 14));
        note.setForeground(TXT_SOFT);
        wrapper.add(note, BorderLayout.NORTH);

        RoundPanel form = new RoundPanel(new GridBagLayout(), 16, CARD, CARD_BORDER, true);
        form.setBorder(new EmptyBorder(22, 24, 22, 24));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 18);
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0;

        JTextField fullName = new JTextField(currentUser.fullName, 24);
        JTextField username = new JTextField(currentUser.username, 24);
        username.setEditable(false);
        username.setToolTipText("Username cannot be changed.");
        JTextField purok = new JTextField(currentUser.purok == null ? "" : currentUser.purok, 24);
        JTextField contact = new JTextField(currentUser.contact == null ? "" : currentUser.contact, 24);
        JTextField address = new JTextField(currentUser.address == null ? "" : currentUser.address, 24);

        JComponent[] fields = {fullName, username, purok, contact, address};
        String[] labels = {"Full Name", "Username", "Purok", "Mobile Number", "Address"};
        for (int i = 0; i < labels.length; i++) {
            c.gridx = 0; c.gridy = i;
            JLabel label = new JLabel(labels[i] + ":");
            label.setFont(font(Font.BOLD, 13));
            label.setForeground(TXT);
            form.add(label, c);
            c.gridx = 1; c.weightx = 1;
            fields[i].setFont(font(Font.PLAIN, 14));
            form.add(fields[i], c);
            c.weightx = 0;
        }

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 4));
        actions.setOpaque(false);
        SettingsButton save = new SettingsButton("Save Information", true);
        save.addActionListener(e -> {
            String err = AuthManager.updateProfile(currentUser, fullName.getText(), purok.getText(),
                    contact.getText(), address.getText());
            if (err != null) {
                JOptionPane.showMessageDialog(this, err, "Account Settings", JOptionPane.WARNING_MESSAGE);
                return;
            }
            JOptionPane.showMessageDialog(this, "Your information has been updated.",
                    "Account Settings", JOptionPane.INFORMATION_MESSAGE);
            showPage("Settings");
        });
        SettingsButton changePassword = new SettingsButton("Change Password", false);
        changePassword.addActionListener(e -> changePasswordDialog());
        actions.add(save);
        actions.add(changePassword);

        JPanel content = new JPanel(new BorderLayout(0, 16));
        content.setOpaque(false);
        content.add(form, BorderLayout.NORTH);
        content.add(actions, BorderLayout.SOUTH);

        JPanel residentSettings = new JPanel();
        residentSettings.setOpaque(false);
        residentSettings.setLayout(new BoxLayout(residentSettings, BoxLayout.Y_AXIS));
        JComponent extras = createSettingsExtras();
        extras.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.setAlignmentX(Component.LEFT_ALIGNMENT);
        residentSettings.add(content);
        residentSettings.add(Box.createVerticalStrut(12));
        residentSettings.add(extras);
        wrapper.add(residentSettings, BorderLayout.CENTER);
        return wrapper;
    }

    /** Residents can update their profile; admins can only change their password here. */
    private static void refreshAnnouncementStores() {
        ListStore.refresh("announcements");
        ListStore.refresh("health");
        ListStore.refresh("education");
    }

    private List<Object[]> announcementNotificationRows() {
        List<Object[]> rows = new ArrayList<>();
        if (isAdmin()) return rows; // announcements are authored by staff; alerts go to residents
        String[][] sources = {{"announcements", "Barangay"}, {"health", "Health"}, {"education", "Education"}};
        for (String[] source : sources) {
            String key = source[0];
            List<Object[]> items = ListStore.get(key);
            for (Object[] item : items) {
                int[] positions = annPositions(key);
                String status = String.valueOf(cell(item, positions[2]));
                if (!"Active".equalsIgnoreCase(status)) continue;
                String title = String.valueOf(cell(item, positions[0]));
                String date = String.valueOf(cell(item, positions[1]));
                String location = announcementLocation(key, item);
                String id = announcementId(item);
                String eventKey = "announcement|" + key + "|" + id;
                String message = title + (date.isBlank() ? "" : " — " + date)
                        + (location.isBlank() ? "" : " — Location: " + location)
                        + ". Open Announcements to view the full details.";
                rows.add(new Object[]{source[1] + " Announcement", message, date, "New", eventKey});
            }
        }
        return rows;
    }

    private List<Object[]> notificationRows() {
        List<Object[]> rows = new ArrayList<>();
        for (Object[] request : RequestStore.forUser(currentUser)) {
            String status = String.valueOf(request[5]).trim();
            if (!"Completed".equalsIgnoreCase(status)) continue;

            String requestId = String.valueOf(request[0]);
            String type = String.valueOf(request[1]);
            String resident = String.valueOf(request[2]);
            int quantity = request.length > 6 ? Math.max(1, Integer.parseInt(String.valueOf(request[6]))) : 1;
            String quantityText = quantity > 1 ? " (" + quantity + " copies)" : "";
            String message = isAdmin()
                    ? "Request " + requestId + " for " + type + quantityText + " from " + resident + " has been marked Completed."
                    : "Your request for " + type + quantityText + " (" + requestId + ") has been completed. You may proceed to the Barangay Hall to claim your document.";
            String completedAt = RequestStore.completedAt(requestId);
            String eventKey = "request|" + requestId + "|" + (completedAt == null ? String.valueOf(request[4]) : completedAt);
            rows.add(new Object[]{"Document Request", message, String.valueOf(request[4]), "Completed", eventKey});
        }
        rows.addAll(announcementNotificationRows());
        return rows;
    }

    private int unreadNotificationCount() {
        int unread = 0;
        for (Object[] row : notificationRows()) {
            if (!viewedNotificationKeys.contains(String.valueOf(row[4]))) unread++;
        }
        return unread;
    }

    /** Mark every notification currently shown as read for this account only. */
    private void markNotificationsAsViewed() {
        boolean changed = false;
        for (Object[] row : notificationRows()) {
            changed |= viewedNotificationKeys.add(String.valueOf(row[4]));
        }
        persistViewedNotificationKeys(changed);
    }

    private int unreadAnnouncementCount() {
        int unread = 0;
        for (Object[] row : announcementNotificationRows())
            if (!viewedNotificationKeys.contains(String.valueOf(row[4]))) unread++;
        return unread;
    }

    private void markAnnouncementNotificationsAsViewed() {
        boolean changed = false;
        for (Object[] row : announcementNotificationRows())
            changed |= viewedNotificationKeys.add(String.valueOf(row[4]));
        persistViewedNotificationKeys(changed);
    }

    private void persistViewedNotificationKeys(boolean changed) {
        if (!changed) return;
        try {
            List<String> keys = new ArrayList<>(viewedNotificationKeys);
            keys.sort(String::compareTo);
            Files.write(notificationReadFile.toPath(), keys, StandardCharsets.UTF_8);
        } catch (Exception ex) {
            System.err.println("Could not save notification read state: " + ex.getMessage());
        }
    }

    /** Play a familiar desktop alert beep followed by a short, soft two-note notification ding. */
    private void playNotificationSound() {
        if (!notificationsEnabled) return;
        Thread sound = new Thread(() -> {
            try {
                // Use the platform's normal alert sound first (for example, Windows system beep).
                try { java.awt.Toolkit.getDefaultToolkit().beep(); } catch (Exception ignored) { }
                Thread.sleep(90L);
                final float sampleRate = 22050f;
                final int firstSamples = (int) (sampleRate * 0.11);
                final int secondSamples = (int) (sampleRate * 0.19);
                final int totalSamples = firstSamples + secondSamples;
                byte[] pcm = new byte[totalSamples * 2];
                for (int i = 0; i < totalSamples; i++) {
                    boolean second = i >= firstSamples;
                    int localIndex = second ? i - firstSamples : i;
                    double t = localIndex / sampleRate;
                    double frequency = second ? 988.0 : 784.0;
                    double attack = Math.min(1.0, t / 0.012);
                    double decay = Math.exp(-(second ? 5.0 : 6.0) * t);
                    double envelope = attack * decay;
                    double wave = Math.sin(2.0 * Math.PI * frequency * t)
                            + 0.22 * Math.sin(4.0 * Math.PI * frequency * t);
                    short sample = (short) (Math.max(-1.0, Math.min(1.0, wave * envelope * 0.24)) * 32767);
                    pcm[i * 2] = (byte) (sample & 0xff);
                    pcm[i * 2 + 1] = (byte) ((sample >>> 8) & 0xff);
                }
                AudioFormat format = new AudioFormat(sampleRate, 16, 1, true, false);
                try (SourceDataLine line = AudioSystem.getSourceDataLine(format)) {
                    line.open(format, pcm.length);
                    line.start();
                    line.write(pcm, 0, pcm.length);
                    line.drain();
                }
            } catch (Exception audioUnavailable) {
                try { java.awt.Toolkit.getDefaultToolkit().beep(); } catch (Exception ignored) { }
            }
        }, "baryokonek-notification-sound");
        sound.setDaemon(true);
        sound.start();
    }

    /** Non-blocking toast shown when a new notification arrives while the app is open. */
    private void showNotificationPopup(List<Object[]> newRows) {
        if (!notificationsEnabled || newRows == null || newRows.isEmpty() || !isShowing()) return;
        if (notificationPopup != null && notificationPopup.isShowing()) notificationPopup.dispose();

        JDialog popup = new JDialog(this, false);
        popup.setUndecorated(true);
        JPanel card = new JPanel(new BorderLayout(10, 8));
        Color popupBg = darkMode ? new Color(9, 23, 45) : Color.WHITE;
        card.setBackground(popupBg);
        card.setBorder(new CompoundBorder(new LineBorder(CARD_BORDER, 2, true), new EmptyBorder(13, 15, 13, 15)));

        JPanel top = new JPanel(new BorderLayout(8, 0));
        top.setOpaque(false);
        JLabel heading = new JLabel(newRows.size() == 1 ? "New Notification" : newRows.size() + " New Notifications");
        heading.setFont(font(Font.BOLD, 15));
        heading.setForeground(TXT);
        top.add(heading, BorderLayout.WEST);
        JLabel close = new JLabel("×");
        close.setFont(font(Font.BOLD, 20));
        close.setForeground(TXT_SOFT);
        close.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        close.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) { popup.dispose(); }
        });
        top.add(close, BorderLayout.EAST);
        card.add(top, BorderLayout.NORTH);

        Object[] latest = newRows.get(newRows.size() - 1);
        JTextArea message = new JTextArea(String.valueOf(latest[1]), 3, 28);
        message.setEditable(false);
        message.setLineWrap(true);
        message.setWrapStyleWord(true);
        message.setOpaque(false);
        message.setForeground(TXT_SOFT);
        message.setFont(font(Font.PLAIN, 13));
        message.setFocusable(false);
        card.add(message, BorderLayout.CENTER);

        PillButton view = new PillButton("View Notifications");
        view.addActionListener(e -> {
            popup.dispose();
            showPage("Notifications");
        });
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        bottom.setOpaque(false);
        bottom.add(view);
        card.add(bottom, BorderLayout.SOUTH);

        popup.setContentPane(card);
        popup.pack();
        popup.setSize(Math.max(320, popup.getWidth()), Math.max(145, popup.getHeight()));
        Point origin = getLocationOnScreen();
        int x = origin.x + getWidth() - popup.getWidth() - 22;
        int y = origin.y + getHeight() - popup.getHeight() - 48;
        popup.setLocation(Math.max(origin.x + 8, x), Math.max(origin.y + 8, y));
        notificationPopup = popup;
        popup.setVisible(true);
        javax.swing.Timer autoClose = new javax.swing.Timer(6500, e -> {
            if (popup.isDisplayable()) popup.dispose();
        });
        autoClose.setRepeats(false);
        autoClose.start();
    }

    private void refreshNotificationBadge() {
        // Turning alerts off hides badge indicators but does not delete or mark notifications read.
        int count = notificationsEnabled ? unreadNotificationCount() : 0;
        int announcements = notificationsEnabled ? unreadAnnouncementCount() : 0;
        for (NavButton button : navButtons) {
            if ("Notifications".equals(button.getText())) button.setBadgeCount(count);
            if ("Announcements".equals(button.getText())) button.setBadgeCount(announcements);
        }
    }

    /** Notification feed with wrapping message cards so the complete text remains readable. */
    private JComponent createNotificationsPage() {
        List<Object[]> rows = notificationRows();
        JPanel page = new JPanel(new BorderLayout(0, 12));
        page.setOpaque(false);
        JLabel info = new JLabel(isAdmin()
                ? "Completed document requests and their status updates appear here."
                : "New announcements and completed document requests appear here.");
        info.setFont(font(Font.PLAIN, 14));
        info.setForeground(TXT_SOFT);
        page.add(info, BorderLayout.NORTH);

        JPanel list = new JPanel();
        list.setOpaque(false);
        list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));
        if (rows.isEmpty()) {
            RoundPanel empty = new RoundPanel(new BorderLayout(), 18, CARD, CARD_BORDER, true);
            empty.setBorder(new EmptyBorder(22, 24, 22, 24));
            JLabel emptyText = new JLabel("No new notifications yet.");
            emptyText.setFont(font(Font.PLAIN, 14));
            emptyText.setForeground(TXT_SOFT);
            empty.add(emptyText, BorderLayout.CENTER);
            empty.setAlignmentX(Component.LEFT_ALIGNMENT);
            empty.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));
            list.add(empty);
        } else {
            for (Object[] row : rows) {
                RoundPanel card = new RoundPanel(new BorderLayout(0, 10), 18, CARD, CARD_BORDER, true);
                card.setBorder(new EmptyBorder(16, 20, 16, 20));
                card.setAlignmentX(Component.LEFT_ALIGNMENT);

                JPanel heading = new JPanel(new BorderLayout(12, 0));
                heading.setOpaque(false);
                JLabel title = new JLabel(String.valueOf(row[0]) + " — " + String.valueOf(row[3]));
                title.setFont(font(Font.BOLD, 15));
                title.setForeground(TXT);
                heading.add(title, BorderLayout.WEST);
                JLabel date = new JLabel("Date: " + String.valueOf(row[2]));
                date.setFont(font(Font.PLAIN, 12));
                date.setForeground(TXT_SOFT);
                heading.add(date, BorderLayout.EAST);

                String messageText = String.valueOf(row[1]);
                JTextArea message = new JTextArea(messageText);
                message.setEditable(false);
                message.setFocusable(false);
                message.setLineWrap(true);
                message.setWrapStyleWord(true);
                message.setOpaque(false);
                message.setFont(font(Font.PLAIN, 14));
                message.setForeground(TXT);
                message.setBorder(new EmptyBorder(0, 0, 0, 0));
                message.setColumns(70);
                int estimatedLines = Math.max(2, (messageText.length() + 59) / 60);
                message.setRows(estimatedLines);
                message.setMaximumSize(new Dimension(Integer.MAX_VALUE, message.getPreferredSize().height));

                card.add(heading, BorderLayout.NORTH);
                card.add(message, BorderLayout.CENTER);
                card.setMaximumSize(new Dimension(Integer.MAX_VALUE, card.getPreferredSize().height));
                list.add(card);
                list.add(Box.createVerticalStrut(12));
            }
        }

        JScrollPane scroll = new JScrollPane(list,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getVerticalScrollBar().setUnitIncrement(18);
        page.add(scroll, BorderLayout.CENTER);
        return page;
    }

    private void changePasswordDialog() {
        JPasswordField oldPw = new JPasswordField(18);
        JPasswordField newPw = new JPasswordField(18);
        JPasswordField confirm = new JPasswordField(18);
        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.add(new JLabel("Current password:")); form.add(oldPw);
        form.add(new JLabel("New password:")); form.add(newPw);
        form.add(new JLabel("Confirm new password:")); form.add(confirm);
        int r = JOptionPane.showConfirmDialog(this, form, "Change Password",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (r != JOptionPane.OK_OPTION) return;
        String err = AuthManager.changePassword(currentUser, new String(oldPw.getPassword()),
                new String(newPw.getPassword()), new String(confirm.getPassword()));
        if (err != null) JOptionPane.showMessageDialog(this, err, "Change Password", JOptionPane.WARNING_MESSAGE);
        else JOptionPane.showMessageDialog(this, "Your password has been changed.", "Change Password", JOptionPane.INFORMATION_MESSAGE);
    }
 
    // =====================================================================
    //  Table card
    // =====================================================================
    private JPanel tableCard(String title, String[] columnsIn, Object[][] rowsIn, String actionIn) {
        // Residents get a read-only view: no Edit/Delete column and no "add" buttons,
        // except for creating their own document requests.
        String[] columns = columnsIn;
        Object[][] rows = rowsIn;
        String actionText = actionIn;
        if (!isAdmin()) {
            boolean residentDocumentRequests = title.toLowerCase().contains("document request");
            int idx = Arrays.asList(columnsIn).indexOf("Actions");
            if (idx >= 0 && !residentDocumentRequests) {
                columns = new String[columnsIn.length - 1];
                for (int i = 0, k = 0; i < columnsIn.length; i++) if (i != idx) columns[k++] = columnsIn[i];
                rows = new Object[rowsIn.length][];
                for (int r = 0; r < rowsIn.length; r++) {
                    rows[r] = new Object[columns.length];
                    for (int i = 0, k = 0; i < columnsIn.length; i++) if (i != idx) rows[r][k++] = rowsIn[r][i];
                }
            }
            if (!residentDocumentRequests) actionText = null;
        }
        final String[] cols = columns;
        final String action = actionText;
 
        RoundPanel card = new RoundPanel(new BorderLayout(0, 14), 20, CARD, CARD_BORDER, true);
        card.setBorder(new EmptyBorder(18, 20, 20, 20));
 
        DefaultTableModel model = new DefaultTableModel(rows, cols) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        JTable table = new JTable(model);
        boolean recentAnnouncementsTable = "Recent Announcements".equals(title);
        boolean requestRecordsTable = title.toLowerCase(Locale.ROOT).contains("request");
        table.setRowHeight(requestRecordsTable ? 44 : 40);
        table.setFont(font(Font.PLAIN, 13));
        table.setBackground(ROW_A);
        table.setShowVerticalLines(false);
        table.setShowHorizontalLines(true);
        table.setGridColor(GRID);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setFillsViewportHeight(true);
        if (recentAnnouncementsTable) {
            // Keep a predictable visible area on Home; additional announcement rows
            // remain accessible with the vertical scrollbar instead of stretching the card.
            table.setPreferredScrollableViewportSize(new Dimension(720, 6 * table.getRowHeight()));
            table.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
        }
        if (requestRecordsTable) {
            // Preferred widths preserve a clean column rhythm while Swing can still
            // expand or contract the columns with the available desktop window width.
            // Minimum widths keep action buttons readable; narrower screens can scroll.
            table.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
        }
        table.setSelectionBackground(SELECT);
        table.setSelectionForeground(TXT);
        table.setDefaultRenderer(Object.class, new BaseRenderer());
 
        for (int i = 0; i < cols.length; i++) {
            TableColumn col = table.getColumnModel().getColumn(i);
            String name = cols[i];
            if (requestRecordsTable) {
                int width;
                switch (name) {
                    case "Request ID": width = 112; break;
                    case "Document Type": width = 160; break;
                    case "Resident Name": width = 165; break;
                    case "Purpose": width = 205; break;
                    case "Date Requested": width = 145; break;
                    case "Quantity": width = 82; break;
                    case "Status": width = 132; break;
                    case "Actions": width = 118; break;
                    default: width = 130; break;
                }
                col.setPreferredWidth(width);
                col.setMinWidth(Math.min(width, 76));
            }
            if (name.equals("Status") || name.equals("Availability"))
                col.setCellRenderer(new PillRenderer(requestRecordsTable));
            else if (requestRecordsTable && (name.equals("Request ID")
                    || name.equals("Date Requested") || name.equals("Quantity")))
                col.setCellRenderer(new CenteredRenderer());
            else if (name.equals("Actions")) {
                if ("Active Barangay Document Requests".equals(title)
                        || "My Active Document Requests".equals(title)) {
                    col.setCellRenderer(new RequestActionRenderer());
                    col.setPreferredWidth(118);
                    col.setMinWidth(110);
                } else col.setCellRenderer(new ActionRenderer());
            }
        }
 
        JTableHeader header = table.getTableHeader();
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(100, 40));
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(t, v, false, false, r, c);
                setOpaque(true);
                setBackground(TH_BG);
                setForeground(TXT);
                setFont(font(Font.BOLD, 13));
                String headerName = String.valueOf(v);
                boolean centeredHeader = requestRecordsTable && ("Request ID".equals(headerName)
                        || "Date Requested".equals(headerName) || "Quantity".equals(headerName)
                        || "Status".equals(headerName) || "Actions".equals(headerName));
                setHorizontalAlignment(centeredHeader ? SwingConstants.CENTER : SwingConstants.LEFT);
                setBorder(new CompoundBorder(new MatteBorder(0, 0, 2, 0, new Color(70, 140, 220)), new EmptyBorder(0, 12, 0, 12)));
                return this;
            }
        });
 
        // ----- top bar: title + search + action
        JPanel top = new JPanel(new BorderLayout(12, 0));
        top.setOpaque(false);
        JLabel heading = new JLabel(title);
        heading.setFont(font(Font.BOLD, 18));
        heading.setForeground(TXT);
        top.add(heading, BorderLayout.WEST);
 
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        controls.setOpaque(false);
        JLabel searchLabel = new JLabel("Search:");
        searchLabel.setFont(font(Font.BOLD, 13));
        searchLabel.setForeground(TXT_SOFT);
        JTextField search = new JTextField(15);
        search.setFont(font(Font.PLAIN, 13));
        search.setForeground(INK);
        search.setToolTipText("Search records");
        search.setBorder(new CompoundBorder(new LineBorder(new Color(196, 212, 226), 1, true), new EmptyBorder(6, 10, 6, 10)));
        controls.add(searchLabel);
        controls.add(search);
        if (action != null) {
            PillButton actionButton = new PillButton(action);
            actionButton.addActionListener(e -> {
                if ("All Announcements".equals(title)) addCombinedAnnouncement();
                else showAddDialog(title, cols, model);
            });
            controls.add(actionButton);
        }
        top.add(controls, BorderLayout.EAST);
        card.add(top, BorderLayout.NORTH);
 
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

        if ("Residents Directory".equals(title)) {
            // Tamang pagkakasunod kapag nag-click sa header ng "Purok" (Purok 2 bago Purok 10)
            sorter.setComparator(2, (a, b) ->
                    Integer.compare(purokNo(String.valueOf(a)), purokNo(String.valueOf(b))));
            // Default na ayos: Purok, tapos Full Name
            sorter.setSortKeys(Arrays.asList(
                    new RowSorter.SortKey(2, SortOrder.ASCENDING),
                    new RowSorter.SortKey(1, SortOrder.ASCENDING)));

            // ----- Sort button (popup menu) na nasa tabi ng Search
            PillButton sortBtn = new PillButton("Sort: Purok 1 \u2192 8");
            JPopupMenu sortMenu = new JPopupMenu();
            Object[][] options = {
                    {"Purok 1 \u2192 8",  SortOrder.ASCENDING,  1, SortOrder.ASCENDING},
                    {"Purok 8 \u2192 1",  SortOrder.DESCENDING, 1, SortOrder.ASCENDING},
                    {"Name A \u2192 Z",   SortOrder.ASCENDING,  -1, null},
                    {"Name Z \u2192 A",   SortOrder.DESCENDING, -1, null}
            };
            for (Object[] o : options) {
                String label = (String) o[0];
                JMenuItem item = new JMenuItem(label);
                item.setFont(font(Font.PLAIN, 13));
                item.addActionListener(e -> {
                    List<RowSorter.SortKey> keys = new ArrayList<>();
                    if (label.startsWith("Purok")) {
                        keys.add(new RowSorter.SortKey(2, (SortOrder) o[1]));   // Purok
                        keys.add(new RowSorter.SortKey(1, SortOrder.ASCENDING)); // tapos pangalan
                    } else {
                        keys.add(new RowSorter.SortKey(1, (SortOrder) o[1]));   // Pangalan lang
                    }
                    sorter.setSortKeys(keys);
                    sortBtn.setText("Sort: " + label);
                    controls.revalidate();
                });
                sortMenu.add(item);
            }
            sortBtn.addActionListener(e -> sortMenu.show(sortBtn, 0, sortBtn.getHeight()));
            controls.add(sortBtn, 0);   // una sa kaliwa ng Search
        }

        search.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            private void filter() {
                String q = search.getText().trim();
                if (q.isEmpty()) sorter.setRowFilter(null);
                else sorter.setRowFilter(RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(q)));
            }
            public void insertUpdate(javax.swing.event.DocumentEvent e) { filter(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { filter(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { filter(); }
        });
 
        JScrollPane scroll = new JScrollPane(table,
                recentAnnouncementsTable ? ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS
                        : ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                requestRecordsTable ? ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED
                        : ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setBorder(new LineBorder(new Color(70, 140, 220, 160)));
        scroll.getViewport().setBackground(ROW_A);
        scroll.getVerticalScrollBar().setUnitIncrement(18);
        if (requestRecordsTable) scroll.getHorizontalScrollBar().setUnitIncrement(18);
        if (recentAnnouncementsTable) {
            // Keep the Recent Announcements viewport at a fixed, compact height.
            // This prevents the dashboard layout from stretching the table to fit all
            // rows, so additional announcements can always be reached by scrolling.
            // ALWAYS keeps the scrollbar visible even before the list becomes long.
            scroll.setWheelScrollingEnabled(true);
            scroll.getVerticalScrollBar().setBlockIncrement(120);
            int visibleRows = 7;
            int viewportHeight = visibleRows * table.getRowHeight();
            table.setPreferredScrollableViewportSize(new Dimension(720, viewportHeight));
            scroll.setPreferredSize(new Dimension(720, viewportHeight + table.getTableHeader().getPreferredSize().height + 4));
            scroll.setMinimumSize(new Dimension(120, 120));
            scroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, viewportHeight + table.getTableHeader().getPreferredSize().height + 4));

            // BorderLayout.CENTER otherwise stretches the scroll pane to the full
            // dashboard height. A vertical BoxLayout wrapper honors its max height.
            JPanel recentScrollHolder = new JPanel();
            recentScrollHolder.setOpaque(false);
            recentScrollHolder.setLayout(new BoxLayout(recentScrollHolder, BoxLayout.Y_AXIS));
            recentScrollHolder.add(scroll);
            card.add(recentScrollHolder, BorderLayout.CENTER);
        } else {
            card.add(scroll, BorderLayout.CENTER);
        }

        // ----- clickable "Edit" / "Delete" in the Actions column (admin only, saved lists)
        final int actIdx = Arrays.asList(cols).indexOf("Actions");
        final String listKey = storeKey(title);
        final boolean combined = "All Announcements".equals(title);
        final boolean residentsTable = "Residents Directory".equals(title);
        final boolean documentRequestActions = "Active Barangay Document Requests".equals(title);
        final boolean residentDocumentRequestActions = "My Active Document Requests".equals(title);
        if (actIdx >= 0 && (listKey != null || combined || residentsTable || documentRequestActions || residentDocumentRequestActions)) {
            table.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                    int vr = table.rowAtPoint(e.getPoint());
                    int vc = table.columnAtPoint(e.getPoint());
                    if (vr < 0 || vc != actIdx) return;
                    int m = table.convertRowIndexToModel(vr);
                    if (documentRequestActions || residentDocumentRequestActions) {
                        String requestedAction = String.valueOf(model.getValueAt(m, actIdx));
                        String requestId = String.valueOf(model.getValueAt(m, 0));
                        if (residentDocumentRequestActions) {
                            if ("Edit".equalsIgnoreCase(requestedAction))
                                showResidentEditRequestDialog(model, m);
                            return;
                        }
                        if ("Accept".equalsIgnoreCase(requestedAction)) {
                            int answer = JOptionPane.showConfirmDialog(BarangayServicesApplication.this,
                                    "Accept request " + requestId + "? Its status will become Pending.",
                                    "Accept Document Request", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                            if (answer == JOptionPane.YES_OPTION) {
                                RequestStore.updateStatus(requestId, "Pending");
                                refreshDocumentRequests();
                                refreshDashboard();
                                refreshNotificationBadge();
                            }
                        } else if ("Complete".equalsIgnoreCase(requestedAction)) {
                            int answer = JOptionPane.showConfirmDialog(BarangayServicesApplication.this,
                                    "Mark request " + requestId + " as Completed? It will move to History.",
                                    "Complete Document Request", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                            if (answer == JOptionPane.YES_OPTION) {
                                RequestStore.updateStatus(requestId, "Completed");
                                refreshDocumentRequests();
                                refreshHistory();
                                refreshDashboard();
                                refreshNotificationBadge();
                            }
                        }
                        return;
                    }
                    Rectangle cell = table.getCellRect(vr, vc, false);
                    FontMetrics fm = table.getFontMetrics(font(Font.BOLD, 13));
                    int x0 = cell.x + 12;                              // left padding of the cell
                    int editEnd = x0 + fm.stringWidth("Edit");
                    int delStart = editEnd + fm.stringWidth(" / ");
                    int delEnd = delStart + fm.stringWidth("Delete");
                    if (residentsTable) {
                        int resEnd = x0 + fm.stringWidth("Delete");
                        if (e.getX() >= x0 && e.getX() <= resEnd) deleteResident(model, m);
                        return;
                    }
                    if (e.getX() >= x0 && e.getX() <= editEnd) {
                        if (combined) editCombinedAnnouncement(m);
                        else showEditItemDialog(title, cols, model, m, listKey);
                    } else if (e.getX() >= delStart && e.getX() <= delEnd) {
                        if (combined) deleteCombinedAnnouncement(m);
                        else deleteItem(model, m, listKey);
                    }
                }
            });
            table.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
                @Override public void mouseMoved(java.awt.event.MouseEvent e) {
                    int vc = table.columnAtPoint(e.getPoint());
                    table.setCursor(Cursor.getPredefinedCursor(
                            vc == actIdx ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR));
                }
            });
        }
        return card;
    }
 
    private void showAddDialog(String title, String[] columns, DefaultTableModel model) {
        if (title.toLowerCase().contains("document request")) {
            JTextField resident = new JTextField(20);
            JTextField purpose = new JTextField(20);
            JSpinner quantity = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
            List<String> availableDocuments = availableDocumentTypes();
            if (availableDocuments.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "There are currently no available documents to request. Please check the Barangay Documents catalog or contact barangay staff.",
                        "No Available Documents", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            JComboBox<String> documentType = new JComboBox<>(availableDocuments.toArray(new String[0]));
            String today = LocalDate.now().format(DateTimeFormatter.ofPattern("MMM dd, yyyy", Locale.ENGLISH));
            JTextField date = new JTextField(today, 20);
            JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
            if (isAdmin()) {
                form.add(new JLabel("Resident Name:")); form.add(resident);
            } else {
                resident.setText(currentUser.fullName);
                resident.setEditable(false);
                form.add(new JLabel("Resident Name:")); form.add(resident);
            }
            form.add(new JLabel("Document Type:")); form.add(documentType);
            form.add(new JLabel("Quantity / Number of Copies:")); form.add(quantity);
            form.add(new JLabel("Purpose:")); form.add(purpose);
            if (isAdmin()) {
                form.add(new JLabel("Date Requested:")); form.add(date);
            }
            int result = JOptionPane.showConfirmDialog(this, form,
                    isAdmin() ? "Create Barangay Document Request" : "Request a Barangay Document",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (result == JOptionPane.OK_OPTION) {
                if (resident.getText().trim().isEmpty() || purpose.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please enter the resident name and purpose.", "Missing Information", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                String selectedDocument = String.valueOf(documentType.getSelectedItem());
                // Validate again before saving so an unavailable item cannot be requested.
                if (!isDocumentCurrentlyAvailable(selectedDocument)) {
                    JOptionPane.showMessageDialog(this,
                            "This document is no longer available. Please select an available document.",
                            "Document Unavailable", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                Object[] row = RequestStore.add(selectedDocument, resident.getText().trim(),
                        purpose.getText().trim(), isAdmin() ? date.getText().trim() : today,
                        "For Acceptance", ((Number) quantity.getValue()).intValue());
                if (!"Completed".equalsIgnoreCase(String.valueOf(row[5]))) {
                    model.addRow(requestTableRows(java.util.Collections.singletonList(row), model.getColumnCount() > 7, isAdmin())[0]);
                }
                refreshHistory();
                refreshDocumentRequests();
                refreshNotificationBadge();
            }
            return;
        }
 
        // Admin creates a real resident login account
        if (title.toLowerCase().contains("residents")) {
            JTextField fullName = new JTextField(20);
            JComboBox<String> purok = new JComboBox<>(new String[]{"Purok 1", "Purok 2", "Purok 3", "Purok 4",
                    "Purok 5", "Purok 6", "Purok 7", "Purok 8"});
            JTextField contact = new JTextField(20);
            JTextField address = new JTextField(20);
            JTextField username = new JTextField(20);
            JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
            form.add(new JLabel("Full Name:")); form.add(fullName);
            form.add(new JLabel("Purok:")); form.add(purok);
            form.add(new JLabel("Mobile Number:")); form.add(contact);
            form.add(new JLabel("Address:")); form.add(address);
            form.add(new JLabel("Username:")); form.add(username);
            int result = JOptionPane.showConfirmDialog(this, form, "Add Resident Account",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (result != JOptionPane.OK_OPTION) return;
            String tempPw = AuthManager.createResidentByAdmin(
                    fullName.getText().trim(),
                    String.valueOf(purok.getSelectedItem()),
                    contact.getText().trim(),
                    address.getText().trim(),
                    username.getText().trim());
            if (tempPw.startsWith("ERROR:")) {
                JOptionPane.showMessageDialog(this, tempPw.substring(7), "Add Resident", JOptionPane.WARNING_MESSAGE);
                return;
            }
            int id = 3 + AuthManager.residents().size();
            model.addRow(new Object[]{
                    String.format("R-%03d", id),
                    fullName.getText().trim(),
                    String.valueOf(purok.getSelectedItem()),
                    contact.getText().trim(),
                    username.getText().trim(),
                    "Active"
            });
            JOptionPane.showMessageDialog(this,
                    "Resident account created successfully.\n\n"
                            + "Username: " + username.getText().trim() + "\n"
                            + "Temporary password: " + tempPw + "\n\n"
                            + "Please give these credentials to the resident.\n"
                            + "They should change the password after first sign-in.",
                    "Resident Account Created", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
 
        // Generic add for health, education and document catalog tables
        String key = storeKey(title);
        String todayText = LocalDate.now().format(DateTimeFormatter.ofPattern("MMM dd, yyyy", Locale.ENGLISH));
        String[] statuses = "documents".equals(key) ? new String[]{"Available", "Unavailable"}
                : new String[]{"Active", "Inactive"};
        JComponent[] inputs = new JComponent[columns.length];
        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        for (int i = 0; i < columns.length; i++) {
            if (columns[i].equals("Actions")) continue;
            form.add(new JLabel(columns[i] + ":"));
            if (columns[i].equals("Status") || columns[i].equals("Availability"))
                inputs[i] = new JComboBox<>(statuses);
            else inputs[i] = new JTextField(columns[i].equals("Date") ? todayText : "", 20);
            form.add(inputs[i]);
        }
        int result = JOptionPane.showConfirmDialog(this, form, "Add to " + title,
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;
        Object[] values = new Object[columns.length];
        for (int i = 0; i < columns.length; i++) {
            if (columns[i].equals("Actions")) values[i] = "Edit / Delete";
            else if (inputs[i] instanceof JComboBox) values[i] = String.valueOf(((JComboBox<?>) inputs[i]).getSelectedItem());
            else values[i] = ((JTextField) inputs[i]).getText().trim();
        }
        if (String.valueOf(values[0]).isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in the " + columns[0] + ".", "Missing Information",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        if ("health".equals(key) || "education".equals(key))
            values = Arrays.copyOf(values, values.length + 1);
        if ("health".equals(key) || "education".equals(key) || "announcements".equals(key))
            values[values.length - 1] = java.util.UUID.randomUUID().toString();
        model.addRow(values);
        if (key != null) ListStore.add(key, values);
    }

    /** Edit an item from Health, Education, Announcements or the document catalog. */
    private void showEditItemDialog(String title, String[] columns, DefaultTableModel model, int m, String key) {
        String[] statuses = "documents".equals(key) ? new String[]{"Available", "Unavailable"}
                : new String[]{"Active", "Inactive"};
        JComponent[] inputs = new JComponent[columns.length];
        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        for (int i = 0; i < columns.length; i++) {
            if (columns[i].equals("Actions")) continue;
            form.add(new JLabel(columns[i] + ":"));
            String current = String.valueOf(model.getValueAt(m, i));
            if (columns[i].equals("Status") || columns[i].equals("Availability")) {
                JComboBox<String> box = new JComboBox<>(statuses);
                box.setSelectedItem(current);
                inputs[i] = box;
            } else {
                inputs[i] = new JTextField(current, 20);
            }
            form.add(inputs[i]);
        }
        int result = JOptionPane.showConfirmDialog(this, form, "Edit " + title,
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;

        Object[] values = new Object[columns.length];
        for (int i = 0; i < columns.length; i++) {
            if (columns[i].equals("Actions")) values[i] = "Edit / Delete";
            else if (inputs[i] instanceof JComboBox) values[i] = String.valueOf(((JComboBox<?>) inputs[i]).getSelectedItem());
            else values[i] = ((JTextField) inputs[i]).getText().trim();
        }
        if (String.valueOf(values[0]).isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in the " + columns[0] + ".",
                    "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Save the changes to this item?",
                "Confirm Edit", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;

        Object[] stored = ListStore.get(key).get(m);
        if (stored.length > values.length) {
            Object[] expanded = Arrays.copyOf(values, stored.length);
            for (int i = values.length; i < stored.length; i++) expanded[i] = stored[i];
            values = expanded;
        }
        for (int i = 0; i < columns.length; i++) model.setValueAt(values[i], m, i);
        ListStore.set(key, m, values);
    }

    /** Admin deletes a registered resident account, with confirmation. */
    private void deleteResident(DefaultTableModel model, int m) {
        String name = String.valueOf(model.getValueAt(m, 1));
        String username = String.valueOf(model.getValueAt(m, 4));
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete the resident \"" + name + "\" (username: " + username + ")?\n"
                        + "Their account will be removed and they will no longer be able to sign in.\n"
                        + "This cannot be undone.",
                "Confirm Delete Resident", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;
        if (!AuthManager.deleteResident(username)) {
            JOptionPane.showMessageDialog(this, "Could not delete this resident.", "Delete Resident",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        model.removeRow(m);
        for (int i = 0; i < model.getRowCount(); i++)
            model.setValueAt(String.format("R-%03d", i + 1), i, 0);   // renumber IDs
    }

    /** Delete an item, with confirmation. */
    private void deleteItem(DefaultTableModel model, int m, String key) {
        String name = String.valueOf(model.getValueAt(m, 0));
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete \"" + name + "\"?\nThis cannot be undone.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;
        model.removeRow(m);
        ListStore.remove(key, m);
    }

    /** Residents may correct their own request details before staff accepts the request. */
    private void showResidentEditRequestDialog(DefaultTableModel model, int modelRow) {
        if (isAdmin()) return;
        String id = String.valueOf(model.getValueAt(modelRow, 0));
        Object[] request = RequestStore.residentEditableRequest(id, currentUser.fullName);
        if (request == null) {
            JOptionPane.showMessageDialog(this,
                    "This request can only be edited before staff accepts it.",
                    "Request Can No Longer Be Edited", JOptionPane.INFORMATION_MESSAGE);
            refreshDocumentRequests();
            return;
        }

        List<String> editableDocumentTypes = availableDocumentTypes();
        String currentDocumentType = String.valueOf(request[1]);
        if (!editableDocumentTypes.contains(currentDocumentType)) editableDocumentTypes.add(0, currentDocumentType);
        JComboBox<String> documentType = new JComboBox<>(editableDocumentTypes.toArray(new String[0]));
        documentType.setSelectedItem(currentDocumentType);
        JTextField purpose = new JTextField(String.valueOf(request[3]), 20);
        JSpinner quantity = new JSpinner(new SpinnerNumberModel(
                Math.max(1, Integer.parseInt(String.valueOf(request[6]))), 1, 100, 1));

        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.add(new JLabel("Request ID:")); form.add(new JLabel(id));
        form.add(new JLabel("Document Type:")); form.add(documentType);
        form.add(new JLabel("Purpose:")); form.add(purpose);
        form.add(new JLabel("Quantity / Number of Copies:")); form.add(quantity);

        int result = JOptionPane.showConfirmDialog(this, form, "Edit Your Document Request",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;
        if (purpose.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Purpose cannot be empty.",
                    "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String type = String.valueOf(documentType.getSelectedItem());
        if (!isDocumentCurrentlyAvailable(type) && !type.equals(currentDocumentType)) {
            JOptionPane.showMessageDialog(this,
                    "This document is no longer available. Please select an available document.",
                    "Document Unavailable", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Save the changes to your request?",
                "Confirm Request Changes", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;

        boolean updated = RequestStore.updateResidentRequest(id, currentUser.fullName,
                type, purpose.getText().trim(), ((Number) quantity.getValue()).intValue());
        if (!updated) {
            JOptionPane.showMessageDialog(this,
                    "The request was already accepted or changed by barangay staff. Please refresh and try again.",
                    "Request Update Not Allowed", JOptionPane.WARNING_MESSAGE);
        }
        refreshDocumentRequests();
        refreshDashboard();
        refreshNotificationBadge();
    }

    public static void main(String[] args) {
        try {
            Database.initialize();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,
                "Cannot connect to PostgreSQL.\\nCheck PostgreSQL and database settings.\\n\\n" + e.getMessage(),
                "Database Connection Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
        SwingUtilities.invokeLater(() -> {
            // Cross-platform (Metal) look & feel is kept on purpose: the system look & feel
            // ignores custom button/label colors on Windows/macOS, which made text invisible.
            new LoginFrame().setVisible(true);
        });
    }
}