-- Run this in pgAdmin Query Tool while connected as the PostgreSQL superuser.
CREATE ROLE baryokonek_app LOGIN PASSWORD 'ChangeThisPassword123!';
