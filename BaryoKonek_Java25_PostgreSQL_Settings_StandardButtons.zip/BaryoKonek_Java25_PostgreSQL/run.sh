#!/bin/sh
cd "$(dirname "$0")"
export BARYOKONEK_DB_URL="${BARYOKONEK_DB_URL:-jdbc:postgresql://localhost:5432/baryokonek}"
export BARYOKONEK_DB_USER="${BARYOKONEK_DB_USER:-baryokonek_app}"
export BARYOKONEK_DB_PASSWORD="${BARYOKONEK_DB_PASSWORD:-ChangeThisPassword123!}"
java -jar target/BaryoKonek.jar
