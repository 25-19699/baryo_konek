# BaryoKonek — Java 25 + PostgreSQL

## Requirements
- Java Development Kit (JDK) 25
- Apache Maven 3.9+
- PostgreSQL 15 or newer (pgAdmin 4 is optional but recommended)


## Account and notification features
- **Admin Barangay Documents** lets staff add catalog entries, edit descriptions and requirements, change availability between Available and Unavailable, and delete entries. Changes are stored in PostgreSQL and are visible in the resident catalog.
- Residents can view the Barangay Documents catalog and submit document requests. The request form lists only documents currently marked **Available** by admin staff; documents marked **Unavailable** are excluded. If no document is available, the app prevents a new request and shows an explanation.
- The request form refreshes the document availability list from PostgreSQL when opened and checks availability again before saving, so changes made by another session are respected.
- The sign-in panel and its Baryo Konek branding are centered together in the login window, while the Resident/Staff tabs, username and password fields, Show Password option, and sign-in controls share a consistent left alignment.
- **Admin Settings** contains only Change Password. **Resident Settings** allows residents to update their own name, purok, mobile number, and address, as well as change their password.
- Usernames are read-only in Settings so account references remain stable.
- **Notifications** shows completed document requests and, for residents, new active Barangay/Health/Education announcements. Residents see a red dot on Announcements while a new announcement is unread and a red counter on Notifications. A short system beep plays when a new notification arrives while the app is open. Notification read state is saved separately for each account.

## 1. Create the PostgreSQL role and database
Open pgAdmin and connect to your local PostgreSQL server.

1. Open **Query Tool** while connected to the default `postgres` database as a superuser.
2. Open and run `database/01_create_user.sql`.
3. Open and run `database/02_create_database.sql` separately.
4. If you changed the password in step 2, use the same password in `run.bat`.

> If the role or database already exists, do not run the corresponding CREATE statement again. Update the role password with `ALTER ROLE baryokonek_app WITH PASSWORD 'your-password';` if needed.

## 2. Build the Java 25 application
Open Command Prompt in the extracted `BaryoKonek_Java25_PostgreSQL` folder and run:

```bat
mvn clean package
```

Maven downloads the PostgreSQL JDBC driver and builds `target/BaryoKonek.jar`.

## 3. Run
Double-click `run.bat`, or run:

```bat
java -jar target/BaryoKonek.jar
```

The app connects to `jdbc:postgresql://localhost:5432/baryokonek`.

## 4. Database login settings
`run.bat` sets these environment variables:
- `BARYOKONEK_DB_URL`
- `BARYOKONEK_DB_USER`
- `BARYOKONEK_DB_PASSWORD`

Change them in `run.bat` if your PostgreSQL username, password, host, or port differs.

## 5. Default staff login
- Username: `admin`
- Password: `admin123`

Change the default password after the first login. Resident accounts are stored in PostgreSQL too.

## 6. Existing TXT data
On first launch, the application imports existing `barangay_users.txt`, `barangay_requests.txt`, and other `barangay_*.txt` list files from the application's current folder when the corresponding PostgreSQL tables are empty. Keep a backup of those files until you verify the imported records.

## Notes
- Database tables are automatically created when the app starts; `database/schema.sql` is also provided for reference.
- The visual design and existing Swing pages are retained.
- Java source targets Java 25. The PostgreSQL JDBC driver is bundled into the shaded JAR by Maven.


## Latest notification and login updates

- The login branding now displays **Barangay Indangan**.
- Admin and resident notification read states are stored separately per account.
- Only document requests with `Completed` status appear in History and generate request-completion notifications.
- A `completed_at` timestamp is recorded when a request changes to `Completed`, so completing the same request again later can create a fresh notification. Existing databases are upgraded automatically at application startup.
- Notification messages use wrapping cards so the full message remains readable.


## Latest interface updates

- The Home page replaces the old Dashboard label and keeps its announcement banner, recent announcements, and scrollable Quick Actions.
- Completed document requests are moved from the active Document Requests list to History; the underlying PostgreSQL request records are retained.
- Residents can request a quantity (number of copies) for each available document.
- New active announcements notify residents with an Announcements red dot and a Notifications entry. A short system beep plays when a new notification arrives while the application is open.
- Barangay, Health, and Education announcements are posted and managed from one unified **Announcements** section in the Admin portal. Category, Date, Location, and Status are retained for each item. Health/Education records from earlier versions remain in PostgreSQL and are included in the unified Announcements list; separate Health Services and Education Services sidebar pages have been removed.
- Light/Dark mode is controlled from Settings. The Events menu has been removed.

The application startup migration adds the `quantity` column to existing `document_requests` tables and expands legacy Health/Education announcement rows with an empty Location field; existing records are preserved.


## Latest layout refinement

- Removed the upper application header completely; the sidebar and page content start at the top edge of the main window.
- Kept the existing sidebar colors, icons, navigation actions, page cards, and user/logout panel design.
- Sidebar navigation scrolls independently when the window is short.
- The sidebar adapts at narrower window sizes: full labels on wide desktop, reduced width at medium sizes, and an icon-only rail with tooltips and a working logout control on narrow/mobile-sized windows.
- Page content keeps a consistent top alignment across Home and all navigation pages; horizontal content insets adapt to the available window width.




## Unified announcements and navigation update

- Admin and residents now see all Barangay, Health, and Education announcement records in the single **Announcements** section. Residents can see the category, full title, date, location, and status; staff can post, edit, and delete every category from the same section.
- The unified list is sorted newest-first when dates are recognizable and does not filter out Inactive records. Active status continues to control resident announcement notification alerts.
- Removed the separate Health Services and Education Services sidebar destinations and the matching Admin Quick Actions. Health and Education categories remain available inside the Admin announcement form so service notices can still be posted without separate pages.
- Announcement data is refreshed for both roles when opening Home, Announcements, or Notifications, and is polled while the application is open so new posts appear in the visible Home/Announcements page.
