-- Run this separately in pgAdmin Query Tool as a PostgreSQL superuser.
CREATE DATABASE baryokonek OWNER baryokonek_app ENCODING 'UTF8';
